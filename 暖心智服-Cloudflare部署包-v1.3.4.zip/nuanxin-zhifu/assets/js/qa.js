/* ============================================================
   暖心智服 · 静态网站  AI 便民助手 —— 本地知识库检索引擎
   ------------------------------------------------------------
   工作原理（检索增强，不是让模型凭空回答）：
   用户提问 → 安全词识别（急症/危险先处置）→ 在【已审核】知识库中
   按关键词与相关度检索 → 组织回答 → 展示来源与核实时间 →
   给出“转人工核实/申请帮扶/反馈问题”入口。
   找不到可靠资料时明确说“暂时无法确定”，绝不编造。
   静态演示版所有计算在本地完成，不向任何外部服务发送问题。
   配置大模型密钥（服务端）后，可把本引擎的检索结果作为
   大模型唯一允许引用的依据，详见 docs/AI服务配置说明.md。
   ============================================================ */
(function (window) {
  'use strict';

  /* 紧急/高危词：出现时优先展示安全转介，不做普通问答 */
  const EMERGENCY_RULES = [
    { words: ['自杀', '不想活', '活不下去', '轻生', '割腕', '跳楼', '结束生命'],
      title: '如果您或身边的人有伤害自己的想法，请立即求助',
      body: '请立刻拨打 110 或 120，或到最近的医院急诊；也请马上联系身边可信的家人、邻居或社区工作人员陪伴，不要独处。' },
    { words: ['被打', '挨打', '家暴', '虐待', '打孩子', '孩子被打', '遗弃', '拐', '走失', '被抢', '被威胁'],
      title: '正在发生人身伤害或儿童危险，请立即报警',
      body: '请立即拨打 110 报警；儿童处于无人监护、受伤害或走失风险时，也可联系社区（村）儿童主任、街道未成年人保护工作站或民政部门。' },
    { words: ['中风', '卒中', '偏瘫', '口角歪', '说话不清', '胸痛', '胸闷', '呼吸困难', '昏迷', '抽搐', '大出血', '呕血', '黑便', '晕倒', '意识不清', '严重过敏', '中毒', '服药过量'],
      title: '这些可能是急症信号，请立即就医',
      body: '请立即拨打 120 或就近急诊。等待急救时让患者平卧、保持气道通畅，不要自行喂水喂药，并记录发病时间。' }
  ];

  const MEDICAL_WORDS = ['吃药', '停药', '换药', '药剂量', '吃什么药', '治疗方案', '康复训练计划', '能治好吗', '诊断', '手术'];

  /* 中文分词（简单稳健：抽取 2 字滑窗 + 关键词表），不依赖外部库 */
  function tokens(text) {
    const set = {};
    const clean = String(text || '').replace(/[\s，。？?！!、,.；;：:“”"'""''（）()【】\[\]…—\-]/g, ' ');
    const parts = clean.split(/\s+/).filter(Boolean);
    parts.forEach(function (p) {
      if (/[a-zA-Z0-9]/.test(p) && p.length <= 12) { set[p.toLowerCase()] = true; }
      for (let i = 0; i < p.length - 1; i++) {
        const bi = p.slice(i, i + 2);
        if (/[\u4e00-\u9fa5]{2}/.test(bi)) set[bi] = true;
      }
      if (/[\u4e00-\u9fa5]/.test(p) && p.length === 1) set[p] = true;
    });
    return Object.keys(set);
  }

  function scoreEntry(entry, qTokens, question) {
    let score = 0;
    const title = entry.title || '';
    const summary = entry.summary || '';
    const content = entry.content || '';
    const keywords = (entry.keywords || '').split(/[,，、\s]+/).filter(Boolean);

    keywords.forEach(function (kw) {
      if (kw && question.indexOf(kw) !== -1) score += 6;
    });
    qTokens.forEach(function (tok) {
      if (title.indexOf(tok) !== -1) score += 3;
      if (summary.indexOf(tok) !== -1) score += 2;
      if (content.indexOf(tok) !== -1) score += 1;
    });
    // 完整问句与标题高度相似时加权
    if (title && question.length >= 6 && title.indexOf(question.slice(0, 8)) !== -1) score += 4;
    return score;
  }

  function detectEmergency(q) {
    for (let i = 0; i < EMERGENCY_RULES.length; i++) {
      const rule = EMERGENCY_RULES[i];
      for (let j = 0; j < rule.words.length; j++) {
        if (q.indexOf(rule.words[j]) !== -1) return rule;
      }
    }
    return null;
  }

  function isMedical(q) {
    return MEDICAL_WORDS.some(function (w) { return q.indexOf(w) !== -1; });
  }

  /**
   * 问答主入口
   * @param {string} question 用户问题
   * @returns {object} {
   *   emergency?: 紧急转介,
   *   matched: bool,
   *   items: 命中的知识库条目（已审核）,
   *   medicalNote?: 医疗边界提示,
   *   logs: 已记录匿名日志
   * }
   */
  function ask(question) {
    const q = String(question || '').trim();
    const result = { question: q, emergency: null, matched: false, items: [], medicalNote: false };
    if (!q) return result;

    // 1) 紧急情况优先
    const em = detectEmergency(q);
    if (em) {
      result.emergency = em;
      Store.logQA(q, true, 'emergency');
      return result;
    }

    // 2) 仅在已审核知识库中检索
    const list = Store.knowledgeList(false);
    const qt = tokens(q);
    const scored = list.map(function (e) {
      return { entry: e, score: scoreEntry(e, qt, q) };
    }).filter(function (x) { return x.score >= 4; })
      .sort(function (a, b) { return b.score - a.score; });

    result.items = scored.slice(0, 3).map(function (x) { return x.entry; });
    result.matched = result.items.length > 0;

    // 3) 医疗类问题补充边界提示
    if (isMedical(q)) result.medicalNote = true;

    Store.logQA(q, result.matched);
    return result;
  }

  /* 建议问题（首页与问答页快捷入口） */
  const SUGGESTIONS = [
    '残疾人两项补贴应该去哪里咨询？',
    '办理补贴一般需要准备什么材料？',
    '家里老人行动不方便，可以申请哪些上门服务？',
    '想申请公益帮扶应该怎么做？',
    '孩子遇到困难或无人监护，可以通过哪些渠道求助？',
    '自闭症儿童家庭可以获得什么支持？',
    '提交申请后多久能安排？服务流程是什么？'
  ];

  window.QA = { ask: ask, SUGGESTIONS: SUGGESTIONS, detectEmergency: detectEmergency };
})(window);
