/* ============================================================
   暖心智服 · 静态网站  前台公共脚本
   语言切换 / 大字版 / 移动菜单 / 当前导航高亮 / 提示条 / 工具函数
   ============================================================ */
(function () {
  'use strict';

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  window.esc = esc;

  /* ---------- Toast ---------- */
  let toastTimer = null;
  window.toast = function (msg, ms) {
    let el = document.getElementById('toast');
    if (!el) {
      el = document.createElement('div');
      el.id = 'toast';
      el.className = 'toast';
      el.setAttribute('role', 'status');
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.hidden = true; }, ms || 3200);
  };

  /* ---------- 常量字典辅助 ---------- */
  window.optionLabel = function (list, value, key) {
    key = key || 'value';
    const hit = list.find(function (x) { return x[key] === value; });
    return hit ? hit.label : value;
  };

  /* ---------- 初始化 ---------- */
  document.addEventListener('DOMContentLoaded', function () {
    const I18N = window.I18N;

    // 语言
    I18N.applyLang(I18N.lang);
    const syncUgNotice = function () {
      document.querySelectorAll('[data-ug-notice]').forEach(function (n) {
        n.hidden = I18N.lang !== 'ug';
      });
    };
    syncUgNotice();
    window.addEventListener('langchange', syncUgNotice);

    document.querySelectorAll('[data-lang-toggle]').forEach(function (btn) {
      btn.addEventListener('click', function () { I18N.toggleLang(); });
    });

    // 大字版
    const fontOn = localStorage.getItem('nxf_large') === '1';
    if (fontOn) document.documentElement.classList.add('large-font');
    document.querySelectorAll('[data-font-toggle]').forEach(function (btn) {
      if (fontOn) btn.setAttribute('aria-pressed', 'true');
      btn.addEventListener('click', function () {
        const on = document.documentElement.classList.toggle('large-font');
        btn.setAttribute('aria-pressed', String(on));
        localStorage.setItem('nxf_large', on ? '1' : '0');
        toast(I18N.t(on ? 'a11y.large_on' : 'a11y.large_off'));
      });
    });

    // 移动端菜单
    const menuBtn = document.querySelector('[data-menu-toggle]');
    const nav = document.getElementById('mainNav');
    if (menuBtn && nav) {
      menuBtn.addEventListener('click', function () {
        const open = nav.classList.toggle('open');
        menuBtn.setAttribute('aria-expanded', String(open));
      });
      nav.querySelectorAll('a').forEach(function (a) {
        a.addEventListener('click', function () {
          nav.classList.remove('open');
          menuBtn.setAttribute('aria-expanded', 'false');
        });
      });
    }

    // 当前导航高亮
    const page = location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('[data-nav]').forEach(function (a) {
      if (a.getAttribute('href') === page || (page === '' && a.getAttribute('href') === 'index.html')) {
        a.classList.add('active');
        a.setAttribute('aria-current', 'page');
      }
    });

    // 关闭演示条
    document.querySelectorAll('[data-dismiss-demo]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        const b = btn.closest('[data-demo-banner]');
        if (b) b.hidden = true;
      });
    });
  });
})();
