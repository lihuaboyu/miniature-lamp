/* ============================================================
   暖心智服 · 管理后台脚本（静态演示版）
   ------------------------------------------------------------
   数据全部来自 localStorage（见 store.js），统计不允许编造。
   登录/权限仅为前端模拟，正式上线必须由服务端校验。
   ============================================================ */
(function () {
  'use strict';

  Store.init();
  var user = Store.currentUser();
  if (!user) { location.href = 'login.html'; return; }

  var C = window.CONSTANTS;
  var appFilter = { status: '' };
  var currentView = 'dashboard';

  /* ---------------- 通用工具 ---------------- */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function label(list, value) {
    var hit = list.find(function (x) { return x.value === value; });
    return hit ? hit.label : value;
  }
  function statusTag(s) {
    var st = C.APP_STATUS[s];
    var cls = {
      pending: 'tag', contacting: 'tag tag-blue', planning: 'tag tag-blue',
      arranged: 'tag tag-green', serving: 'tag tag-green',
      followup: 'tag tag-orange', closed: 'tag', rejected: 'tag tag-red'
    }[s] || 'tag';
    return '<span class="' + cls + '">' + esc(st.label) + '</span>';
  }
  function maskPhone(p) {
    p = p || '';
    if (p.length < 7) return p;
    return p.slice(0, 3) + '****' + p.slice(-4);
  }

  /* ---------------- 弹窗 ---------------- */
  function openModal(title, bodyHtml, footerHtml) {
    $('#modalRoot').innerHTML =
      '<div class="a-modal-mask" id="aMask">' +
        '<div class="a-modal" role="dialog" aria-modal="true">' +
          '<div class="a-modal-head"><h3>' + esc(title) +
            '<button type="button" class="modal-close" id="aClose" style="position:static">×</button>' +
          '</h3></div>' +
          '<div class="a-modal-body">' + bodyHtml + '</div>' +
          '<div class="a-modal-foot">' + (footerHtml || '') + '</div>' +
        '</div>' +
      '</div>';
    var mask = $('#aMask');
    mask.addEventListener('click', function (e) { if (e.target === mask) closeModal(); });
    $('#aClose').addEventListener('click', closeModal);
  }
  function closeModal() { $('#modalRoot').innerHTML = ''; }
  function val(id) { var el = $('#' + id); return el ? el.value.trim() : ''; }

  /* ---------------- 视图路由 ---------------- */
  var VIEWS = [
    { key: 'dashboard', title: '工作台', roles: ['admin', 'manager', 'staff'] },
    { key: 'applications', title: '申请管理', roles: ['admin', 'manager', 'staff'] },
    { key: 'orders', title: '服务工单', roles: ['admin', 'manager', 'staff'] },
    { key: 'followups', title: '回访与投诉', roles: ['admin', 'manager', 'staff'] },
    { key: 'schedules', title: '服务排班', roles: ['admin', 'manager', 'staff'] },
    { key: 'reminders', title: '回访提醒', roles: ['admin', 'manager', 'staff'] },
    { key: 'knowledge', title: '政策知识库', roles: ['admin', 'manager'] },
    { key: 'local', title: '便民信息', roles: ['admin', 'manager'] },
    { key: 'articles', title: '康复科普', roles: ['admin', 'manager'] },
    { key: 'feedback', title: '意见反馈', roles: ['admin', 'manager'] },
    { key: 'volunteers', title: '志愿者管理', roles: ['admin', 'manager'] },
    { key: 'trainings', title: '培训记录', roles: ['admin', 'manager'] },
    { key: 'report', title: '数据统计', roles: ['admin', 'manager'] },
    { key: 'qaquality', title: '问答质量分析', roles: ['admin', 'manager'] },
    { key: 'logs', title: '操作日志', roles: ['admin', 'manager'] }
  ];

  function setView(key) {
    var v = VIEWS.find(function (x) { return x.key === key; });
    if (!v || v.roles.indexOf(user.role) === -1) { toast('当前角色无权访问该模块'); return; }
    currentView = key;
    $('#viewTitle').textContent = v.title;
    $all('#adminNav button[data-view]').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-view') === key);
    });
    RENDER[key]();
    $('#sidebar').classList.remove('open');
  }

  /* ---------------- 工作台 ---------------- */
  function renderDashboard() {
    var s = Store.stats();
    var apps = Store.applicationList().slice(0, 6);
    var qaLogs = Store.qaLogs();
    var unmatched = qaLogs.filter(function (l) { return !l.matched; }).slice(0, 8);
    var fmtN = function (n) { return '<span class="num' + (n ? ' orange' : '') + '">' + n + '</span>'; };

    var cards = [
      [s.pending, '待审核申请'],
      [s.contacting, '联系中'],
      [s.planning, '待安排'],
      [s.arranged, '已安排'],
      [s.serving, '服务中'],
      [s.followup, '待回访'],
      [s.closed, '已完成（结案）'],
      [s.rejected, '暂无法处理']
    ];
    var html =
      '<div class="notice-bar notice-info" style="margin-bottom:16px">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M9 12l2 2 4-4"/></svg>' +
        '<div>静态试点版统计：所有数字均来自当前浏览器本地数据，未接入服务器。数据为 0 时显示 0，不做任何编造。</div>' +
      '</div>' +
      '<div class="stat-grid">' +
        cards.map(function (c) {
          return '<div class="stat-card"><div class="num">' + c[0] + '</div><div class="lbl">' + c[1] + '</div></div>';
        }).join('') +
        '<div class="stat-card"><div class="num blue">' + s.total + '</div><div class="lbl">申请总数</div></div>' +
        '<div class="stat-card"><div class="num">' + s.orders + '</div><div class="lbl">工单总数</div></div>' +
        '<div class="stat-card"><div class="num">' + s.followups + '</div><div class="lbl">回访记录</div></div>' +
        '<div class="stat-card"><div class="num red">' + s.complaintsOpen + '</div><div class="lbl">待处理投诉</div></div>' +
      '</div>';

    html += '<div class="panel"><div class="panel-head"><h2>最新申请</h2>' +
      '<button class="btn btn-outline btn-sm" type="button" data-go="applications">查看全部</button></div>';
    if (!apps.length) {
      html += '<div class="empty-state"><p>暂无申请记录。可在前台“公益帮扶”页面提交测试申请，或由工作人员登记需求。</p></div>';
    } else {
      html += '<div class="table-wrap"><table><thead><tr><th>服务编号</th><th>类型</th><th>地区</th><th>状态</th><th>提交时间</th></tr></thead><tbody>';
      apps.forEach(function (a) {
        html += '<tr><td>' + esc(a.code) + '</td><td>' + esc(label(C.SERVICE_TYPES, a.type)) +
          '</td><td>' + esc(a.region) + '</td><td>' + statusTag(a.status) +
          '</td><td>' + esc(a.createdAt) + '</td></tr>';
      });
      html += '</tbody></table></div>';
    }
    html += '</div>';

    html += '<div class="panel"><div class="panel-head"><h2>知识库与问答质量</h2></div>' +
      '<div class="stat-grid" style="margin-bottom:12px">' +
        '<div class="stat-card"><div class="num">' + s.knowledgeApproved + '</div><div class="lbl">已审核条目（进入问答）</div></div>' +
        '<div class="stat-card"><div class="num orange">' + s.knowledgeDraft + '</div><div class="lbl">待核实/待审核条目</div></div>' +
        '<div class="stat-card"><div class="num">' + qaLogs.length + '</div><div class="lbl">问答记录（匿名）</div></div>' +
        '<div class="stat-card"><div class="num red">' + unmatched.length + '</div><div class="lbl">近期无依据问题（需补充）</div></div>' +
      '</div>';
    if (unmatched.length) {
      html += '<div class="mini-log"><b>最近“答不上来”的问题：</b>' +
        unmatched.map(function (l) { return '<div>· ' + esc(l.q) + '（' + esc(l.at) + '）</div>'; }).join('') + '</div>';
    } else {
      html += '<div class="panel-note">暂无无依据问题记录。</div>';
    }
    html += '</div>';

    $('#adminContent').innerHTML = html;
  }

  /* ---------------- 申请管理 ---------------- */
  function renderApplications() {
    var list = Store.applicationList();
    var filtered = appFilter.status ? list.filter(function (a) { return a.status === appFilter.status; }) : list;
    var html =
      '<div class="filter-bar">' +
        '<select id="appStatusFilter"><option value="">全部状态</option>' +
          Object.keys(C.APP_STATUS).map(function (k) {
            return '<option value="' + k + '"' + (appFilter.status === k ? ' selected' : '') + '>' + C.APP_STATUS[k].label + '</option>';
          }).join('') +
        '</select>' +
        '<span class="panel-note">共 ' + filtered.length + ' 条（状态必须按流程逐步推进，不能跳步）</span>' +
      '</div>';

    if (!filtered.length) {
      html += '<div class="empty-state"><p>该状态下暂无申请。</p></div>';
    } else {
      filtered.forEach(function (a) {
        var order = Store.orderList().find(function (o) { return o.appCode === a.code; });
        html += '<div class="admin-item">' +
          '<div class="admin-item-head">' +
            '<div><div class="admin-item-title">' + esc(a.code) + '　' + statusTag(a.status) + '</div>' +
            '<div class="admin-item-meta">' +
              '<span>类型：' + esc(label(C.SERVICE_TYPES, a.type)) + '</span>' +
              '<span>地区：' + esc(a.region) + (a.regionDetail ? ' / ' + esc(a.regionDetail) : '') + '</span>' +
              '<span>联系人：' + esc(a.contactName || '未留称呼') + ' / ' + esc(maskPhone(a.phone)) + '</span>' +
              '<span>方便联系：' + esc(a.contactTime || '不限') + '</span>' +
              (a.guardianName ? '<span>监护人：' + esc(a.guardianName) + '（已同意）</span>' : '') +
              '<span>提交：' + esc(a.createdAt) + '</span>' +
            '</div></div>' +
          '</div>' +
          '<div class="admin-item-body"><b>需求简述：</b>' + esc(a.need) + '</div>' +
          (a.internalNote ? '<div class="mini-log"><b>内部备注：</b>' + esc(a.internalNote) + '</div>' : '') +
          (a.contactLog && a.contactLog.length ?
            '<div class="mini-log"><b>联系记录：</b>' + a.contactLog.map(function (l) {
              return '<div>' + esc(l.at) + ' ' + esc(l.by) + '：' + esc(l.text) + '</div>';
            }).join('') + '</div>' : '') +
          (a.rejectReason ? '<div class="notice-bar notice-danger" style="margin-top:10px"><div>暂无法处理原因：' + esc(a.rejectReason) + '</div></div>' : '') +
          '<div class="admin-actions">' + appActionButtons(a, order) + '</div>' +
        '</div>';
      });
    }
    $('#adminContent').innerHTML = html;

    $('#appStatusFilter').addEventListener('change', function () {
      appFilter.status = this.value; renderApplications();
    });
  }

  function appActionButtons(a, order) {
    var btns = [];
    var canEdit = ['admin', 'manager', 'staff'].indexOf(user.role) >= 0;
    if (!canEdit) return '';
    btns.push('<button class="btn btn-outline btn-sm" type="button" data-act="note" data-id="' + a.id + '">联系记录/备注</button>');
    switch (a.status) {
      case 'pending':
        btns.push('<button class="btn btn-primary btn-sm" type="button" data-act="to" data-id="' + a.id + '" data-next="contacting">电话核实，进入联系中</button>');
        btns.push('<button class="btn btn-outline btn-sm" type="button" data-act="reject" data-id="' + a.id + '">暂无法处理</button>');
        break;
      case 'contacting':
        btns.push('<button class="btn btn-primary btn-sm" type="button" data-act="to" data-id="' + a.id + '" data-next="planning">评估完成，进入待安排</button>');
        btns.push('<button class="btn btn-outline btn-sm" type="button" data-act="reject" data-id="' + a.id + '">暂无法处理</button>');
        break;
      case 'planning':
        btns.push('<button class="btn btn-accent btn-sm" type="button" data-act="order" data-id="' + a.id + '">创建工单并派单</button>');
        btns.push('<button class="btn btn-outline btn-sm" type="button" data-act="reject" data-id="' + a.id + '">暂无法处理</button>');
        break;
      case 'arranged':
        btns.push('<a class="btn btn-outline btn-sm" href="#orders" data-go="orders">前往工单录入服务</a>');
        break;
      case 'serving':
        btns.push('<a class="btn btn-outline btn-sm" href="#orders" data-go="orders">前往工单/回访</a>');
        break;
      case 'followup':
        btns.push('<a class="btn btn-outline btn-sm" href="#orders" data-go="orders">前往回访结案</a>');
        break;
      case 'closed':
        btns.push('<span class="tag tag-green">已结案</span>');
        break;
      case 'rejected':
        btns.push('<span class="tag tag-red">暂无法处理</span>');
        break;
    }
    return btns.join('');
  }

  function appDetail(id) {
    var a = Store.getApplication(id);
    if (a) { setView('applications'); }
  }

  /* ---------------- 工单 ---------------- */
  function renderOrders() {
    var orders = Store.orderList();
    var html = '<div class="panel-note" style="margin-bottom:14px">工单由“待安排”状态的申请创建；填写服务记录后工单进入服务中，服务结束后登记回访并结案。</div>';
    if (!orders.length) {
      html += '<div class="empty-state"><p>暂无工单。请先在“申请管理”中核实申请并创建工单。</p></div>';
    } else {
      orders.forEach(function (o) {
        html += '<div class="admin-item">' +
          '<div class="admin-item-head">' +
            '<div><div class="admin-item-title">' + esc(o.code) + '　' + statusTag(o.status) + '</div>' +
            '<div class="admin-item-meta">' +
              '<span>对应申请：' + esc(o.appCode) + '</span>' +
              '<span>服务类型：' + esc(label(C.SERVICE_TYPES, o.serviceType)) + '</span>' +
              '<span>负责人：' + esc(o.owner || '未指定') + '</span>' +
              '<span>计划时间：' + esc(o.plannedAt || '未填写') + '</span>' +
            '</div></div>' +
          '</div>' +
          (o.progress ? '<div class="admin-item-body"><b>服务进展：</b>' + esc(o.progress) + '</div>' : '') +
          (o.records && o.records.length ?
            '<div class="mini-log"><b>服务记录：</b>' + o.records.map(function (r) {
              return '<div>' + esc(r.at) + ' ' + esc(r.by) + '：' + esc(r.text) + '</div>';
            }).join('') + '</div>' : '<div class="panel-note" style="margin-top:6px">暂无服务记录。</div>') +
          (o.rejectReason ? '<div class="notice-bar notice-danger" style="margin-top:10px"><div>暂无法处理：' + esc(o.rejectReason) + (o.referral ? '；转介建议：' + esc(o.referral) : '') + '</div></div>' : '') +
          '<div class="admin-actions">' + orderButtons(o) + '</div>' +
        '</div>';
      });
    }
    $('#adminContent').innerHTML = html;
  }

  function orderButtons(o) {
    var btns = ['<button class="btn btn-outline btn-sm" type="button" data-act="oedit" data-id="' + o.id + '">更新负责人/时间</button>'];
    if (o.status === 'rejected' || o.status === 'closed') {
      btns.push(o.status === 'closed' ? '<span class="tag tag-green">已结案</span>' : '<span class="tag tag-red">暂无法处理</span>');
      return btns.join('');
    }
    if (o.status === 'arranged' || o.status === 'serving') {
      btns.push('<button class="btn btn-primary btn-sm" type="button" data-act="orecord" data-id="' + o.id + '">填写服务记录</button>');
    }
    if (o.status === 'serving') {
      btns.push('<button class="btn btn-accent btn-sm" type="button" data-act="followup" data-id="' + o.id + '">服务结束，登记回访</button>');
    }
    if (o.status === 'followup') {
      btns.push('<button class="btn btn-accent btn-sm" type="button" data-act="close" data-id="' + o.id + '">结案</button>');
    }
    if (o.status !== 'followup') {
      btns.push('<button class="btn btn-outline btn-sm" type="button" data-act="oreject" data-id="' + o.id + '">暂无法处理</button>');
    }
    return btns.join('');
  }

  /* ---------------- 回访与投诉 ---------------- */
  function renderFollowups() {
    var html = '<div class="panel"><div class="panel-head"><h2>回访管理</h2>' +
      '<button class="btn btn-primary btn-sm" type="button" id="addFollowupBtn">登记回访</button></div>';
    var fus = Store.followupList();
    if (!fus.length) {
      html += '<div class="empty-state"><p>暂无回访记录。服务结束后请及时电话/上门回访，记录满意度。</p></div>';
    } else {
      html += '<div class="table-wrap"><table><thead><tr><th>申请编号</th><th>方式</th><th>满意度</th><th>内容</th><th>回访人</th><th>时间</th></tr></thead><tbody>';
      fus.forEach(function (f) {
        var star = f.satisfaction ? '★'.repeat(f.satisfaction) + '☆'.repeat(5 - f.satisfaction) : '—';
        html += '<tr><td>' + esc(f.appCode) + '</td><td>' + esc(f.method) + '</td><td>' + star + '</td><td>' + esc(f.content || '—') + '</td><td>' + esc(f.by) + '</td><td>' + esc(f.at) + '</td></tr>';
      });
      html += '</tbody></table></div>';
    }
    html += '</div>';

    html += '<div class="panel"><div class="panel-head"><h2>投诉管理</h2>' +
      '<button class="btn btn-outline btn-sm" type="button" id="addComplaintBtn">登记投诉</button></div>' +
      '<div class="panel-note">处理流程：登记 → 处理中 → 整改中 → 再访 → 办结；处理措施与整改结果均留痕。</div>';
    var cs = Store.complaintList();
    if (!cs.length) {
      html += '<div class="empty-state"><p>暂无投诉记录。</p></div>';
    } else {
      cs.forEach(function (c) {
        html += '<div class="admin-item"><div class="admin-item-head">' +
          '<div><div class="admin-item-title">' + esc(c.id) + '　<span class="tag tag-orange">' + esc(c.status) + '</span></div>' +
          '<div class="admin-item-meta"><span>涉及申请：' + esc(c.appCode || '—') + '</span><span>渠道：' + esc(c.channel) + '</span><span>登记：' + esc(c.at) + ' ' + esc(c.by) + '</span></div></div>' +
          '<div class="admin-actions"><button class="btn btn-outline btn-sm" type="button" data-act="cedit" data-id="' + c.id + '">处理 / 整改 / 办结</button></div>' +
          '</div><div class="admin-item-body">' + esc(c.content) + '</div>' +
          (c.handling ? '<div class="mini-log"><b>处理情况：</b>' + esc(c.handling) + '</div>' : '') +
          (c.rectify ? '<div class="mini-log"><b>整改措施：</b>' + esc(c.rectify) + '</div>' : '') +
          (c.revisit ? '<div class="mini-log"><b>再次回访：</b>' + esc(c.revisit) + '</div>' : '') +
          (c.result ? '<div class="mini-log"><b>最终结果：</b>' + esc(c.result) + '</div>' : '') +
        '</div>';
      });
    }
    html += '</div>';

    $('#adminContent').innerHTML = html;
    $('#addFollowupBtn').addEventListener('click', followupModal);
    $('#addComplaintBtn').addEventListener('click', complaintModal);
  }

  function followupModal() {
    var opts = Store.applicationList()
      .filter(function (a) { return ['serving', 'followup', 'arranged'].indexOf(a.status) >= 0; })
      .map(function (a) { return '<option value="' + esc(a.code) + '">' + esc(a.code) + '（' + esc(C.APP_STATUS[a.status].label) + '）</option>'; }).join('');
    openModal('登记回访',
      '<div class="form-row"><label class="field-label">服务编号</label><select id="fCode" class="input">' + (opts || '<option value="">暂无可回访的工单</option>') + '</select></div>' +
      '<div class="form-row"><label class="field-label">回访方式</label><select id="fMethod" class="input"><option>电话回访</option><option>上门回访</option><option>微信回访</option></select></div>' +
      '<div class="form-row"><label class="field-label">满意度</label><select id="fSat" class="input"><option value="5">★★★★★ 非常满意</option><option value="4">★★★★ 满意</option><option value="3">★★★ 一般</option><option value="2">★★ 不满意</option><option value="1">★ 很不满意</option></select></div>' +
      '<div class="form-row"><label class="field-label">回访内容</label><textarea id="fContent" placeholder="服务是否到位、服务对象反馈、后续需求等"></textarea></div>' +
      '<div class="form-row"><label class="field-label">结案小结（可选，登记后可直接结案）</label><input class="input" id="fSummary" placeholder="如：已完成本月 4 次上门，服务对象满意，予以结案"></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-primary" type="button" id="mOk">登记回访</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      var code = val('fCode');
      if (!code) { toast('暂无可回访的工单'); return; }
      Store.addFollowup(code, val('fMethod'), Number(val('fSat')), val('fContent'));
      var summary = val('fSummary');
      if (summary) {
        var r = Store.closeCase(code, summary);
        if (!r.ok) toast(r.msg);
      }
      closeModal(); toast('回访已登记'); renderFollowups();
    });
  }

  function complaintModal() {
    var codes = Store.applicationList().map(function (a) { return '<option value="' + esc(a.code) + '">' + esc(a.code) + '</option>'; }).join('');
    openModal('登记投诉',
      '<div class="form-row"><label class="field-label">涉及服务编号（可留空）</label><select id="cCode" class="input"><option value="">不关联具体工单</option>' + codes + '</select></div>' +
      '<div class="form-row"><label class="field-label">来源渠道</label><select id="cChannel" class="input"><option>电话</option><option>现场</option><option>线上反馈</option><option>社区转来</option></select></div>' +
      '<div class="form-row"><label class="field-label">投诉内容</label><textarea id="cContent" placeholder="客观记录投诉人反映的问题"></textarea></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-primary" type="button" id="mOk">登记</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      if (val('cContent').length < 5) { toast('请填写投诉内容'); return; }
      Store.addComplaint({ appCode: val('cCode'), channel: val('cChannel'), content: val('cContent'), status: '登记' });
      closeModal(); toast('投诉已登记'); renderFollowups();
    });
  }

  function complaintEditModal(id) {
    var c = Store.complaintList().find(function (x) { return x.id === id; });
    if (!c) return;
    openModal('投诉处理（' + c.id + '）',
      '<div class="form-row"><label class="field-label">当前状态</label><select id="sStatus" class="input">' +
        ['登记', '处理中', '整改中', '再访', '办结'].map(function (s) {
          return '<option ' + (c.status === s ? 'selected' : '') + '>' + s + '</option>';
        }).join('') + '</select></div>' +
      '<div class="form-row"><label class="field-label">处理情况</label><textarea id="sHandling">' + esc(c.handling || '') + '</textarea></div>' +
      '<div class="form-row"><label class="field-label">整改措施</label><textarea id="sRectify">' + esc(c.rectify || '') + '</textarea></div>' +
      '<div class="form-row"><label class="field-label">再次回访情况</label><textarea id="sRevisit">' + esc(c.revisit || '') + '</textarea></div>' +
      '<div class="form-row"><label class="field-label">最终处理结果</label><textarea id="sResult">' + esc(c.result || '') + '</textarea></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-primary" type="button" id="mOk">保存</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      Store.updateComplaint(id, {
        status: val('sStatus'), handling: val('sHandling'), rectify: val('sRectify'),
        revisit: val('sRevisit'), result: val('sResult')
      });
      closeModal(); toast('已保存'); renderFollowups();
    });
  }

  /* ---------------- 知识库 ---------------- */
  function renderKnowledge() {
    var list = Store.knowledgeList(true);
    var html = '<div class="panel-note" style="margin-bottom:14px">只有“已审核”的条目会进入 AI 问答；补贴金额、申请条件等未经核实的内容必须保持草稿，不得对外答复。</div>' +
      '<div class="admin-actions" style="margin-bottom:14px"><button class="btn btn-primary btn-sm" type="button" id="newK">新增知识条目</button></div>';
    list.forEach(function (k) {
      var tag = k.status === 'approved' ? '<span class="tag tag-green">已审核</span>' : '<span class="tag tag-demo">待核实/草稿</span>';
      html += '<div class="admin-item"><div class="admin-item-head">' +
        '<div><div class="admin-item-title">' + esc(k.title) + '　' + tag + '</div>' +
        '<div class="admin-item-meta"><span>分类：' + esc(label(C.KNOWLEDGE_CATEGORIES, k.category)) + '</span><span>地区：' + esc(k.region) + '</span><span>来源：' + esc(k.sourceName) + '</span><span>核实：' + esc(k.verifiedAt || '未核实') + '</span><span>维护：' + esc(k.maintainer || '—') + '</span></div></div>' +
        '<div class="admin-actions">' +
          '<button class="btn btn-outline btn-sm" type="button" data-act="kedit" data-id="' + k.id + '">编辑</button>' +
          (k.status === 'approved'
            ? '<button class="btn btn-outline btn-sm" type="button" data-act="kdraft" data-id="' + k.id + '">停用（退回草稿）</button>'
            : '<button class="btn btn-primary btn-sm" type="button" data-act="kapprove" data-id="' + k.id + '">审核通过（进入问答）</button>') +
        '</div></div>' +
        '<div class="admin-item-body">' + esc(k.summary) + '</div></div>';
    });
    $('#adminContent').innerHTML = html;
    $('#newK').addEventListener('click', function () { knowledgeModal(null); });
  }

  function knowledgeModal(id) {
    var k = id ? Store.knowledgeList(true).find(function (x) { return x.id === id; }) : {
      title: '', summary: '', content: '', category: 'project_service', region: '通用',
      keywords: '', sourceName: '', sourceUrl: '', publishedAt: '', verifiedAt: '',
      status: 'draft', maintainer: user.realName
    };
    if (!k) return;
    var catOpts = C.KNOWLEDGE_CATEGORIES.map(function (c) {
      return '<option value="' + c.value + '"' + (k.category === c.value ? ' selected' : '') + '>' + c.label + '</option>';
    }).join('');
    openModal(id ? '编辑知识条目' : '新增知识条目',
      '<div class="form-row"><label class="field-label">标题</label><input class="input" id="kTitle" value="' + esc(k.title) + '"></div>' +
      '<div class="form-grid two-col"><div class="form-row"><label class="field-label">分类</label><select id="kCategory" class="input">' + catOpts + '</select></div>' +
      '<div class="form-row"><label class="field-label">适用地区</label><input class="input" id="kRegion" value="' + esc(k.region) + '"></div></div>' +
      '<div class="form-row"><label class="field-label">摘要（回答正文）</label><textarea id="kSummary">' + esc(k.summary) + '</textarea></div>' +
      '<div class="form-row"><label class="field-label">详细办理指引</label><textarea id="kContent" style="min-height:150px">' + esc(k.content) + '</textarea></div>' +
      '<div class="form-row"><label class="field-label">关键词（逗号分隔，用于检索）</label><input class="input" id="kKeywords" value="' + esc(k.keywords) + '"></div>' +
      '<div class="form-grid two-col"><div class="form-row"><label class="field-label">来源名称</label><input class="input" id="kSource" value="' + esc(k.sourceName) + '"></div>' +
      '<div class="form-row"><label class="field-label">来源链接</label><input class="input" id="kUrl" value="' + esc(k.sourceUrl || '') + '"></div></div>' +
      '<div class="form-grid two-col"><div class="form-row"><label class="field-label">发布日期（可留空）</label><input class="input" id="kPublished" value="' + esc(k.publishedAt || '') + '" placeholder="YYYY-MM-DD"></div>' +
      '<div class="form-row"><label class="field-label">最后核实日期</label><input class="input" id="kVerified" value="' + esc(k.verifiedAt || '') + '" placeholder="YYYY-MM-DD"></div></div>' +
      '<div class="form-row"><label class="field-label">维护人</label><input class="input" id="kMaintainer" value="' + esc(k.maintainer || '') + '"></div>' +
      '<div class="notice-bar notice-warn"><div>没有来源、没有核实日期的条目请保持“草稿”，审核通过后才会进入 AI 问答。</div></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-primary" type="button" id="mOk">保存</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      if (val('kTitle').length < 4 || val('kSummary').length < 5) { toast('请填写标题和摘要'); return; }
      var item = {
        id: k.id || '', title: val('kTitle'), summary: val('kSummary'),
        content: $('#kContent').value, category: val('kCategory'), region: val('kRegion'),
        keywords: val('kKeywords'), sourceName: val('kSource'), sourceUrl: val('kUrl'),
        publishedAt: val('kPublished'), verifiedAt: val('kVerified'),
        status: k.status || 'draft', maintainer: val('kMaintainer')
      };
      if (!item.sourceName) { toast('请填写来源名称（依据）'); return; }
      Store.knowledgeSave(item);
      closeModal(); toast('已保存'); renderKnowledge();
    });
  }

  /* ---------------- 便民信息 ---------------- */
  function renderLocal() {
    var list = Store.localList(true);
    var html = '<div class="panel-note" style="margin-bottom:14px">未经核实的记录必须保留“待核实”标记，核实通过后改为“已核实”；前台仅展示已核实信息。</div>' +
      '<div class="admin-actions" style="margin-bottom:14px"><button class="btn btn-primary btn-sm" type="button" id="newL">新增便民信息</button></div>';
    list.forEach(function (l) {
      var tag = l.status === 'demo' ? '<span class="tag tag-demo">待核实</span>' : '<span class="tag tag-green">已核实</span>';
      html += '<div class="admin-item"><div class="admin-item-head">' +
        '<div><div class="admin-item-title">' + esc(l.name) + '　' + tag + '</div>' +
        '<div class="admin-item-meta"><span>类别：' + esc(label(C.LOCAL_CATEGORIES, l.category)) + '</span><span>地区：' + esc(l.region) + '</span><span>核实：' + esc(l.verifiedAt || '未核实') + '</span></div></div>' +
        '<div class="admin-actions"><button class="btn btn-outline btn-sm" type="button" data-act="ledit" data-id="' + l.id + '">编辑</button></div>' +
        '</div><div class="admin-item-body">' + esc(l.description) + '</div></div>';
    });
    $('#adminContent').innerHTML = html;
    $('#newL').addEventListener('click', function () { localModal(null); });
  }

  function localModal(id) {
    var l = id ? Store.localList(true).find(function (x) { return x.id === id; }) : {
      name: '', category: 'gov', region: '', description: '', contact: '', website: '',
      source: '', verifiedAt: '', status: 'demo'
    };
    if (!l) return;
    var catOpts = C.LOCAL_CATEGORIES.map(function (c) {
      return '<option value="' + c.value + '"' + (l.category === c.value ? ' selected' : '') + '>' + c.label + '</option>';
    }).join('');
    openModal(id ? '编辑便民信息' : '新增便民信息',
      '<div class="form-row"><label class="field-label">机构/渠道名称</label><input class="input" id="lName" value="' + esc(l.name) + '"></div>' +
      '<div class="form-grid two-col"><div class="form-row"><label class="field-label">类别</label><select id="lCategory" class="input">' + catOpts + '</select></div>' +
      '<div class="form-row"><label class="field-label">所属地区</label><input class="input" id="lRegion" value="' + esc(l.region) + '"></div></div>' +
      '<div class="form-row"><label class="field-label">服务说明</label><textarea id="lDesc">' + esc(l.description) + '</textarea></div>' +
      '<div class="form-grid two-col"><div class="form-row"><label class="field-label">联系方式（电话或说明）</label><input class="input" id="lContact" value="' + esc(l.contact) + '"></div>' +
      '<div class="form-row"><label class="field-label">官方网站（可留空）</label><input class="input" id="lUrl" value="' + esc(l.website || '') + '"></div></div>' +
      '<div class="form-grid two-col"><div class="form-row"><label class="field-label">来源/核实依据</label><input class="input" id="lSource" value="' + esc(l.source) + '"></div>' +
      '<div class="form-row"><label class="field-label">最后核实日期</label><input class="input" id="lVerified" value="' + esc(l.verifiedAt || '') + '" placeholder="YYYY-MM-DD"></div></div>' +
      '<div class="form-row"><label class="field-label">状态</label><select id="lStatus" class="input"><option value="demo"' + (l.status === 'demo' ? ' selected' : '') + '>待核实（前台显著打标）</option><option value="verified"' + (l.status === 'verified' ? ' selected' : '') + '>已核实（正式信息）</option></select></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-primary" type="button" id="mOk">保存</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      if (val('lName').length < 2 || val('lDesc').length < 5) { toast('请填写名称和服务说明'); return; }
      if (val('lStatus') === 'verified' && !val('lVerified')) { toast('标记为“已核实”前必须填写核实日期和来源'); return; }
      Store.localSave({
        id: l.id || '', name: val('lName'), category: val('lCategory'), region: val('lRegion'),
        description: val('lDesc'), contact: val('lContact'), website: val('lUrl'),
        source: val('lSource'), verifiedAt: val('lVerified'), status: val('lStatus')
      });
      closeModal(); toast('已保存'); renderLocal();
    });
  }

  /* ---------------- 科普文章 ---------------- */
  function renderArticles() {
    var list = Store.articleList(true);
    var html = '<div class="panel-note" style="margin-bottom:14px">科普文章须由康复/护理专业教师审核通过后才在前台显示为“已审核”；AI 生成内容不得直接作为专业治疗方案。</div>' +
      '<div class="admin-actions" style="margin-bottom:14px"><button class="btn btn-primary btn-sm" type="button" id="newA">新增科普文章</button></div>';
    list.forEach(function (a) {
      var tag = a.status === 'approved' ? '<span class="tag tag-green">已审核</span>' : '<span class="tag tag-demo">待专业审核</span>';
      html += '<div class="admin-item"><div class="admin-item-head">' +
        '<div><div class="admin-item-title">' + esc(a.title) + '　' + tag + '</div>' +
        '<div class="admin-item-meta"><span>分类：' + esc(label(C.ARTICLE_CATEGORIES, a.category)) + '</span><span>更新：' + esc(a.updatedAt) + '</span><span>审核：' + esc(a.reviewedBy || '—') + '</span></div></div>' +
        '<div class="admin-actions">' +
          '<button class="btn btn-outline btn-sm" type="button" data-act="aedit" data-id="' + a.id + '">编辑</button>' +
          (a.status === 'approved'
            ? '<button class="btn btn-outline btn-sm" type="button" data-act="adraft" data-id="' + a.id + '">撤回到待审核</button>'
            : '<button class="btn btn-primary btn-sm" type="button" data-act="aapprove" data-id="' + a.id + '">审核通过</button>') +
        '</div></div></div>';
    });
    $('#adminContent').innerHTML = html;
    $('#newA').addEventListener('click', function () { articleModal(null); });
  }

  function articleModal(id) {
    var a = id ? Store.articleList(true).find(function (x) { return x.id === id; }) : {
      title: '', category: 'rehab_basic', content: '', status: 'draft', reviewedBy: ''
    };
    if (!a) return;
    var catOpts = C.ARTICLE_CATEGORIES.map(function (c) {
      return '<option value="' + c.value + '"' + (a.category === c.value ? ' selected' : '') + '>' + c.label + '</option>';
    }).join('');
    openModal(id ? '编辑科普文章' : '新增科普文章',
      '<div class="form-row"><label class="field-label">标题</label><input class="input" id="aTitle" value="' + esc(a.title) + '"></div>' +
      '<div class="form-row"><label class="field-label">分类</label><select id="aCategory" class="input">' + catOpts + '</select></div>' +
      '<div class="form-row"><label class="field-label">正文</label><textarea id="aContent" style="min-height:200px">' + esc(a.content) + '</textarea></div>' +
      '<div class="form-row"><label class="field-label">审核人（专业教师）</label><input class="input" id="aReviewer" value="' + esc(a.reviewedBy || '') + '"></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-primary" type="button" id="mOk">保存草稿</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      if (val('aTitle').length < 4 || $('#aContent').value.trim().length < 10) { toast('请填写标题和正文'); return; }
      Store.articleSave({
        id: a.id || '', title: val('aTitle'), category: val('aCategory'),
        content: $('#aContent').value, status: 'draft', reviewedBy: val('aReviewer')
      });
      closeModal(); toast('草稿已保存（审核通过后才会标记为已审核）'); renderArticles();
    });
  }

  /* ---------------- 反馈 ---------------- */
  function renderFeedback() {
    var list = Store.feedbackList();
    var html = '<div class="panel-note" style="margin-bottom:14px">居民通过“意见反馈”提交的内容；静态试点版仅保存在本浏览器。</div>';
    if (!list.length) {
      html += '<div class="empty-state"><p>暂无意见反馈。</p></div>';
    } else {
      list.forEach(function (f) {
        html += '<div class="admin-item"><div class="admin-item-head">' +
          '<div><div class="admin-item-title">' + esc(f.type) + '</div>' +
          '<div class="admin-item-meta"><span>' + esc(f.at) + '</span>' + (f.contact ? '<span>联系方式：' + esc(f.contact) + '</span>' : '') + '</div></div>' +
          '</div><div class="admin-item-body">' + esc(f.content) + '</div></div>';
      });
    }
    $('#adminContent').innerHTML = html;
  }

  /* ---------------- 日志 ---------------- */
  function renderLogs() {
    var list = Store.auditLogs();
    var html = '<div class="panel-note" style="margin-bottom:14px">敏感信息查看、状态变更、内容审核等关键操作均记录日志（静态试点版）。</div>';
    if (!list.length) {
      html += '<div class="empty-state"><p>暂无操作日志。</p></div>';
    } else {
      html += '<div class="table-wrap"><table><thead><tr><th style="width:150px">时间</th><th style="width:110px">操作人</th><th style="width:90px">角色</th><th style="width:170px">动作</th><th>对象</th></tr></thead><tbody>';
      list.forEach(function (l) {
        html += '<tr><td>' + esc(l.at) + '</td><td>' + esc(l.actor) + '</td><td>' + esc(l.role) + '</td><td>' + esc(l.action) + '</td><td>' + esc(l.target) + '</td></tr>';
      });
      html += '</tbody></table></div>';
    }
    $('#adminContent').innerHTML = html;
  }

  /* ============================================================
     第二阶段：志愿者 / 培训 / 排班 / 提醒 / 统计 / 问答质量
     ============================================================ */
  function constTag(groupKey, value) {
    var green = { VOLUNTEER_STATUS: ['active'], TRAINING_STATUS: ['done'], SCHEDULE_STATUS: ['done'] };
    var blue = { TRAINING_STATUS: ['planned'], SCHEDULE_STATUS: ['planned'] };
    var red = { VOLUNTEER_STATUS: ['inactive'], TRAINING_STATUS: ['canceled'], SCHEDULE_STATUS: ['canceled'] };
    var cls = (green[groupKey] || []).indexOf(value) >= 0 ? 'tag tag-green'
      : (blue[groupKey] || []).indexOf(value) >= 0 ? 'tag tag-blue'
      : (red[groupKey] || []).indexOf(value) >= 0 ? 'tag tag-red' : 'tag';
    return '<span class="' + cls + '">' + esc(C[groupKey][value].label) + '</span>';
  }

  /* ---------------- 志愿者管理 ---------------- */
  function renderVolunteers() {
    var list = Store.volunteerList();
    var html = '<div class="panel"><div class="panel-head"><h2>团队与志愿者名册</h2>' +
      '<button class="btn btn-primary btn-sm" type="button" data-act="vadd">新增成员/志愿者</button></div>' +
      '<div class="panel-note">名册仅登记已获本人同意的项目成员与志愿者；完成岗前培训、状态为“在岗”者才可安排服务排班。' +
      '联系方式仅在后台可见，不向前台和外部展示。</div>';
    if (!list.length) {
      html += '<div class="empty-state"><p>暂无志愿者。点击右上角“新增志愿者”登记。</p></div>';
    } else {
      html += '<div class="table-wrap"><table><thead><tr>' +
        '<th>称呼</th><th>身份/专业</th><th>双语</th><th>培训</th><th>状态</th><th>片区</th><th>累计时长</th><th>操作</th>' +
        '</tr></thead><tbody>';
      list.forEach(function (v) {
        var major = label(C.VOLUNTEER_MAJORS, v.major);
        html += '<tr>' +
          '<td>' + (v.demo ? '<span class="tag tag-red">测试</span> ' : '') + esc(v.name) +
          (v.phone ? '<div class="admin-item-meta">' + esc(maskPhone(v.phone)) + '</div>' : '') + '</td>' +
          '<td>' + esc(v.kind === 'staff' ? '工作人员' : '学生志愿者') + '<br>' + esc(major) +
          (v.grade ? '<span class="admin-item-meta">' + esc(v.grade) + '</span>' : '') + '</td>' +
          '<td>' + (v.bilingual ? '汉维双语' : '汉语') + '</td>' +
          '<td>' + (v.trained ? '<span class="tag tag-green">已完成</span>' : '<span class="tag tag-red">未完成</span>') + '</td>' +
          '<td>' + constTag('VOLUNTEER_STATUS', v.status) + '</td>' +
          '<td>' + esc(v.region || '—') + '</td>' +
          '<td>' + (Number(v.serviceHours) || 0) + ' 小时</td>' +
          '<td>' +
            '<button class="btn btn-outline btn-sm" type="button" data-act="vedit" data-id="' + v.id + '">编辑</button> ' +
            (v.status === 'active'
              ? '<button class="btn btn-outline btn-sm" type="button" data-act="vstatus" data-id="' + v.id + '" data-next="paused">暂停</button>'
              : '<button class="btn btn-outline btn-sm" type="button" data-act="vstatus" data-id="' + v.id + '" data-next="active">恢复在岗</button>') +
            (v.status !== 'inactive' ? ' <button class="btn btn-outline btn-sm" type="button" data-act="vstatus" data-id="' + v.id + '" data-next="inactive">退出</button>' : '') +
          '</td>' +
        '</tr>';
      });
      html += '</tbody></table></div>';
    }
    html += '</div>';
    $('#adminContent').innerHTML = html;
  }

  function volunteerModal(id) {
    var v = id ? Store.volunteerList().find(function (x) { return x.id === id; }) : {
      name: '', kind: 'student', major: 'nursing', grade: '', bilingual: true, skills: '',
      trained: false, status: 'active', region: '', phone: '', serviceHours: 0, note: ''
    };
    if (id && !v) return;
    var majorOpts = C.VOLUNTEER_MAJORS.map(function (m) {
      return '<option value="' + m.value + '"' + (v.major === m.value ? ' selected' : '') + '>' + m.label + '</option>';
    }).join('');
    openModal(id ? '编辑志愿者' : '新增志愿者',
      '<div class="form-row"><label class="field-label">称呼（公开场合建议使用化名）</label><input class="input" id="vName" value="' + esc(v.name || '') + '"></div>' +
      '<div class="form-row"><label class="field-label">身份</label><select class="input" id="vKind">' +
        '<option value="student"' + (v.kind === 'student' ? ' selected' : '') + '>学生志愿者</option>' +
        '<option value="staff"' + (v.kind === 'staff' ? ' selected' : '') + '>工作人员</option></select></div>' +
      '<div class="form-row"><label class="field-label">专业背景</label><select class="input" id="vMajor">' + majorOpts + '</select></div>' +
      '<div class="form-row"><label class="field-label">年级（选填）</label><input class="input" id="vGrade" value="' + esc(v.grade || '') + '"></div>' +
      '<div class="form-row"><label class="field-label">服务片区</label><input class="input" id="vRegion" value="' + esc(v.region || '') + '"></div>' +
      '<div class="form-row"><label class="field-label">联系电话（仅后台可见）</label><input class="input" id="vPhone" value="' + esc(v.phone || '') + '"></div>' +
      '<div class="form-row"><label class="field-label">技能与可服务内容</label><input class="input" id="vSkills" value="' + esc(v.skills || '') + '" placeholder="如：生活照料、助洁、课业辅导、康复辅助"></div>' +
      '<div class="form-row"><label class="field-label">累计服务时长（小时，完成排班自动累加）</label><input class="input" id="vHours" type="number" min="0" value="' + (Number(v.serviceHours) || 0) + '"></div>' +
      '<div class="form-row"><label class="field-label"><input type="checkbox" id="vBilingual"' + (v.bilingual ? ' checked' : '') + '> 具备汉维双语沟通能力</label></div>' +
      '<div class="form-row"><label class="field-label"><input type="checkbox" id="vTrained"' + (v.trained ? ' checked' : '') + '> 已完成岗前培训</label></div>' +
      '<div class="form-row"><label class="field-label">状态</label><select class="input" id="vStatus">' +
        ['active', 'paused', 'inactive'].map(function (s) {
          return '<option value="' + s + '"' + (v.status === s ? ' selected' : '') + '>' + C.VOLUNTEER_STATUS[s].label + '</option>';
        }).join('') + '</select></div>' +
      '<div class="form-row"><label class="field-label">备注</label><textarea id="vNote">' + esc(v.note || '') + '</textarea></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-primary" type="button" id="mOk">保存</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      if (!val('vName')) { toast('请填写志愿者称呼'); return; }
      var data = {
        id: v.id || '', name: val('vName'), kind: $('#vKind').value, major: $('#vMajor').value,
        grade: val('vGrade'), region: val('vRegion'), phone: val('vPhone'), skills: val('vSkills'),
        serviceHours: Number($('#vHours').value) || 0,
        bilingual: $('#vBilingual').checked, trained: $('#vTrained').checked,
        status: $('#vStatus').value, note: $('#vNote').value
      };
      var r = Store.volunteerSave(data);
      if (!r.ok) { toast(r.msg); return; }
      closeModal(); toast('已保存'); renderVolunteers();
    });
  }

  /* ---------------- 培训记录 ---------------- */
  function renderTrainings() {
    var list = Store.trainingList().slice().sort(function (a, b) {
      return (a.date || '9999').localeCompare(b.date || '9999');
    });
    var html = '<div class="panel"><div class="panel-head"><h2>培训记录</h2>' +
      '<button class="btn btn-primary btn-sm" type="button" data-act="tadd">新增培训</button></div>' +
      '<div class="panel-note">对应《项目综述》的志愿者培训与服务质量管理要求：岗前培训合格后方可参与排班。</div>';
    if (!list.length) {
      html += '<div class="empty-state"><p>暂无培训记录。</p></div>';
    } else {
      html += '<div class="table-wrap"><table><thead><tr>' +
        '<th>培训主题</th><th>类别</th><th>日期</th><th>讲师</th><th>课时</th><th>参训人数</th><th>状态</th><th>操作</th>' +
        '</tr></thead><tbody>';
      list.forEach(function (t) {
        html += '<tr>' +
          '<td>' + (t.demo ? '<span class="tag tag-red">测试</span> ' : '') + esc(t.title) +
          (t.content ? '<div class="admin-item-meta">' + esc(t.content) + '</div>' : '') + '</td>' +
          '<td>' + esc(label(C.TRAINING_TYPES, t.type)) + '</td>' +
          '<td>' + esc(t.date || '待定') + '</td>' +
          '<td>' + esc(t.trainer || '待定') + '</td>' +
          '<td>' + (Number(t.hours) || 0) + ' 课时</td>' +
          '<td>' + (Number(t.attendees) || 0) + ' 人</td>' +
          '<td>' + constTag('TRAINING_STATUS', t.status) + '</td>' +
          '<td>' +
            '<button class="btn btn-outline btn-sm" type="button" data-act="tedit" data-id="' + t.id + '">编辑</button> ' +
            (t.status !== 'done' ? '<button class="btn btn-outline btn-sm" type="button" data-act="tstatus" data-id="' + t.id + '" data-next="done">标记完成</button> ' : '') +
            (t.status !== 'canceled' ? '<button class="btn btn-outline btn-sm" type="button" data-act="tstatus" data-id="' + t.id + '" data-next="canceled">取消</button>' : '') +
          '</td>' +
        '</tr>';
      });
      html += '</tbody></table></div>';
    }
    html += '</div>';
    $('#adminContent').innerHTML = html;
  }

  function trainingModal(id) {
    var t = id ? Store.trainingList().find(function (x) { return x.id === id; }) : {
      title: '', type: 'induction', date: '', trainer: '', hours: 2, attendees: 0, content: '', status: 'planned'
    };
    if (id && !t) return;
    var typeOpts = C.TRAINING_TYPES.map(function (x) {
      return '<option value="' + x.value + '"' + (t.type === x.value ? ' selected' : '') + '>' + x.label + '</option>';
    }).join('');
    openModal(id ? '编辑培训记录' : '新增培训',
      '<div class="form-row"><label class="field-label">培训主题</label><input class="input" id="tTitle" value="' + esc(t.title || '') + '"></div>' +
      '<div class="form-row"><label class="field-label">培训类别</label><select class="input" id="tType">' + typeOpts + '</select></div>' +
      '<div class="form-row"><label class="field-label">日期（计划中可留空）</label><input class="input" id="tDate" type="date" value="' + esc(t.date || '') + '"></div>' +
      '<div class="form-row"><label class="field-label">讲师/负责人</label><input class="input" id="tTrainer" value="' + esc(t.trainer || '') + '"></div>' +
      '<div class="form-row"><label class="field-label">课时数</label><input class="input" id="tHours" type="number" min="0" step="0.5" value="' + (Number(t.hours) || 0) + '"></div>' +
      '<div class="form-row"><label class="field-label">参训人数</label><input class="input" id="tAttendees" type="number" min="0" value="' + (Number(t.attendees) || 0) + '"></div>' +
      '<div class="form-row"><label class="field-label">培训内容</label><textarea id="tContent">' + esc(t.content || '') + '</textarea></div>' +
      '<div class="form-row"><label class="field-label">状态</label><select class="input" id="tStatus">' +
        ['planned', 'done', 'canceled'].map(function (s) {
          return '<option value="' + s + '"' + (t.status === s ? ' selected' : '') + '>' + C.TRAINING_STATUS[s].label + '</option>';
        }).join('') + '</select></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-primary" type="button" id="mOk">保存</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      if (!val('tTitle')) { toast('请填写培训主题'); return; }
      var data = {
        id: t.id || '', title: val('tTitle'), type: $('#tType').value, date: val('tDate'),
        trainer: val('tTrainer'), hours: Number($('#tHours').value) || 0,
        attendees: Number($('#tAttendees').value) || 0, content: $('#tContent').value, status: $('#tStatus').value
      };
      var r = Store.trainingSave(data);
      if (!r.ok) { toast(r.msg); return; }
      closeModal(); toast('已保存'); renderTrainings();
    });
  }

  /* ---------------- 服务排班 ---------------- */
  function renderSchedules() {
    var list = Store.scheduleList();
    var html = '<div class="panel"><div class="panel-head"><h2>服务排班</h2>' +
      '<button class="btn btn-primary btn-sm" type="button" data-act="scadd">新增排班</button></div>' +
      '<div class="panel-note">按日期升序排列；仅可选择“已完成岗前培训、在岗”的志愿者；标记完成后服务时长自动计入志愿者档案。</div>';
    if (!list.length) {
      html += '<div class="empty-state"><p>暂无排班。创建工单后可在此安排上门服务时间。</p></div>';
    } else {
      var groups = {};
      list.forEach(function (sc) {
        (groups[sc.date] = groups[sc.date] || []).push(sc);
      });
      Object.keys(groups).forEach(function (d) {
        html += '<div class="schedule-day"><h3>' + esc(d) + '</h3>';
        groups[d].forEach(function (sc) {
          html += '<div class="admin-item">' +
            '<div class="admin-item-head"><div>' +
              '<div class="admin-item-title">' + esc(sc.slot || '上午') + '　' + esc(sc.volunteerName) + '　' + constTag('SCHEDULE_STATUS', sc.status) + '</div>' +
              '<div class="admin-item-meta">' +
                (sc.appCode ? '<span>工单：' + esc(sc.appCode) + '</span>' : '') +
                (sc.serviceType ? '<span>类型：' + esc(label(C.SERVICE_TYPES, sc.serviceType)) + '</span>' : '') +
                '<span>计划时长：' + (Number(sc.hours) || 0) + ' 小时</span>' +
              '</div></div></div>' +
            (sc.note ? '<div class="admin-item-body">' + esc(sc.note) + '</div>' : '') +
            '<div class="admin-actions">' +
              (sc.status === 'planned'
                ? '<button class="btn btn-primary btn-sm" type="button" data-act="scdone" data-id="' + sc.id + '">服务完成</button> ' +
                  '<button class="btn btn-outline btn-sm" type="button" data-act="sccancel" data-id="' + sc.id + '">取消排班</button> '
                : '') +
              '<button class="btn btn-outline btn-sm" type="button" data-act="scdel" data-id="' + sc.id + '">删除</button>' +
            '</div>' +
          '</div>';
        });
        html += '</div>';
      });
    }
    html += '</div>';
    $('#adminContent').innerHTML = html;
  }

  function scheduleModal() {
    var eligible = Store.volunteerList().filter(function (v) { return v.trained && v.status === 'active'; });
    var vOpts = eligible.length ? eligible.map(function (v) {
      return '<option value="' + esc(v.name) + '">' + esc(v.name) + '（' + esc(label(C.VOLUNTEER_MAJORS, v.major)) + (v.bilingual ? '·双语' : '') + '）</option>';
    }).join('') : '';
    var orders = Store.orderList().filter(function (o) { return ['arranged', 'serving'].indexOf(o.status) >= 0; });
    var oOpts = '<option value="">不关联工单（非入户事项）</option>' + orders.map(function (o) {
      return '<option value="' + esc(o.id) + '" data-code="' + esc(o.appCode) + '" data-type="' + esc(o.serviceType) + '">' +
        esc(o.appCode) + '（' + esc(C.APP_STATUS[o.status].label) + '）</option>';
    }).join('');
    openModal('新增排班',
      (eligible.length ? '' : '<div class="notice-bar notice-danger" style="margin-bottom:12px"><div>当前没有“已培训且在岗”的志愿者，请先在「志愿者管理」中登记并完成培训。</div></div>') +
      '<div class="form-row"><label class="field-label">关联工单（可选）</label><select class="input" id="scOrder">' + oOpts + '</select></div>' +
      '<div class="form-row"><label class="field-label">服务日期</label><input class="input" id="scDate" type="date" value="' + Store.todayStr() + '"></div>' +
      '<div class="form-row"><label class="field-label">时段</label><select class="input" id="scSlot">' +
        C.SCHEDULE_SLOTS.map(function (s) { return '<option>' + s + '</option>'; }).join('') + '</select></div>' +
      '<div class="form-row"><label class="field-label">志愿者/工作人员</label><select class="input" id="scVol">' +
        (vOpts || '<option value="">暂无可排班志愿者</option>') + '</select></div>' +
      '<div class="form-row"><label class="field-label">计划时长（小时）</label><input class="input" id="scHours" type="number" min="0.5" step="0.5" value="2"></div>' +
      '<div class="form-row"><label class="field-label">备注</label><textarea id="scNote" placeholder="如：老人卧床，需要两人协助；请准备维语沟通。"></textarea></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-accent" type="button" id="mOk">确认排班</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      if (!val('scDate')) { toast('请选择日期'); return; }
      if (!eligible.length || !val('scVol')) { toast('没有可排班的志愿者'); return; }
      var appCode = '', serviceType = '';
      var os = $('#scOrder').selectedOptions[0];
      if (os && os.value) { appCode = os.getAttribute('data-code'); serviceType = os.getAttribute('data-type'); }
      var r = Store.scheduleCreate({
        appCode: appCode, serviceType: serviceType,
        date: val('scDate'), slot: val('scSlot'), volunteerName: val('scVol'),
        hours: Number($('#scHours').value) || 0, note: $('#scNote').value
      });
      if (!r.ok) { toast(r.msg); return; }
      closeModal(); toast('排班已保存'); renderSchedules();
    });
  }

  /* ---------------- 回访提醒 ---------------- */
  function renderReminders() {
    var list = Store.reminderList();
    var overdue = list.filter(function (r) { return r.overdue && !r.done; });
    var html = '<div class="panel"><div class="panel-head"><h2>回访提醒</h2>' +
      '<button class="btn btn-primary btn-sm" type="button" data-act="rmadd">新增提醒</button></div>' +
      '<div class="panel-note">系统自动生成：服务中 3 天未回访、回访后 2 天未结案；也可手动登记提醒。逾期事项红色提示。</div>' +
      (overdue.length ? '<div class="notice-bar notice-danger" style="margin-bottom:12px"><div>有 ' + overdue.length + ' 项提醒已逾期，请尽快处理。</div></div>' :
        '<div class="notice-bar notice-info" style="margin-bottom:12px"><div>暂无逾期提醒。</div></div>');
    if (!list.length) {
      html += '<div class="empty-state"><p>暂无提醒事项。</p></div>';
    } else {
      html += '<div class="table-wrap"><table><thead><tr>' +
        '<th style="width:120px">到期日</th><th>事项</th><th style="width:110px">类型</th><th style="width:150px">操作</th>' +
        '</tr></thead><tbody>';
      list.forEach(function (r) {
        html += '<tr' + (r.done ? ' style="opacity:.55"' : '') + '>' +
          '<td>' + esc(r.dueDate) +
          (r.overdue && !r.done ? '<div><span class="tag tag-red">已逾期</span></div>' : '') + '</td>' +
          '<td>' + (r.kind === 'manual' ? '' : '<span class="tag tag-blue">系统</span> ') + esc(r.content) + '</td>' +
          '<td>' + (r.kind === 'manual' ? '人工提醒' : '自动提醒') + (r.done ? '（已完成）' : '') + '</td>' +
          '<td>' +
            (r.appCode ? '<button class="btn btn-outline btn-sm" type="button" data-go="orders">查看工单</button> ' : '') +
            (r.kind === 'manual' && !r.done ? '<button class="btn btn-primary btn-sm" type="button" data-act="rmdone" data-id="' + r.id + '">完成</button> ' : '') +
            (r.kind === 'manual' ? '<button class="btn btn-outline btn-sm" type="button" data-act="rmdel" data-id="' + r.id + '">删除</button>' : '') +
          '</td>' +
        '</tr>';
      });
      html += '</tbody></table></div>';
    }
    html += '</div>';
    $('#adminContent').innerHTML = html;
  }

  function reminderModal() {
    var opts = Store.applicationList().filter(function (a) {
      return ['arranged', 'serving', 'followup'].indexOf(a.status) >= 0;
    }).map(function (a) {
      return '<option value="' + esc(a.code) + '">' + esc(a.code) + '（' + esc(C.APP_STATUS[a.status].label) + '）</option>';
    }).join('');
    openModal('新增回访提醒',
      '<div class="form-row"><label class="field-label">关联服务编号（可选）</label><select class="input" id="rCode"><option value="">不关联</option>' + opts + '</select></div>' +
      '<div class="form-row"><label class="field-label">到期日期</label><input class="input" id="rDate" type="date" value="' + Store.todayStr() + '"></div>' +
      '<div class="form-row"><label class="field-label">提醒事项</label><textarea id="rContent" placeholder="如：10 月 28 日前电话回访本月第二次服务满意度。"></textarea></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-primary" type="button" id="mOk">保存提醒</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      var r = Store.reminderCreate({ appCode: val('rCode'), dueDate: val('rDate'), content: val('rContent') });
      if (!r.ok) { toast(r.msg); return; }
      closeModal(); toast('提醒已保存'); renderReminders();
    });
  }

  /* ---------------- 数据统计 ---------------- */
  function barRow(labelText, value, max, color) {
    var pct = max > 0 ? Math.round(value / max * 100) : 0;
    return '<div class="chart-row">' +
      '<span class="chart-label">' + esc(labelText) + '</span>' +
      '<span class="chart-track"><span class="chart-fill" style="width:' + pct + '%;background:' + (color || '#1f7a5d') + '"></span></span>' +
      '<span class="chart-val">' + value + '</span></div>';
  }

  function renderReport() {
    var d = Store.reportData();
    var s = Store.stats();
    var closureRate = s.total ? Math.round(s.closed / s.total * 100) : 0;
    var html = '<div class="notice-bar notice-info" style="margin-bottom:16px"><div>静态试点版统计：以下数字全部来自当前浏览器本地真实记录，无记录时显示 0，不做任何编造。</div></div>';

    html += '<div class="stat-grid">' +
      '<div class="stat-card"><div class="num">' + s.total + '</div><div class="lbl">累计申请</div></div>' +
      '<div class="stat-card"><div class="num">' + s.orders + '</div><div class="lbl">累计工单</div></div>' +
      '<div class="stat-card"><div class="num">' + s.closed + '</div><div class="lbl">已结案</div></div>' +
      '<div class="stat-card"><div class="num blue">' + closureRate + '%</div><div class="lbl">结案率</div></div>' +
      '<div class="stat-card"><div class="num">' + d.volunteers.active + '</div><div class="lbl">在岗志愿者（已培训 ' + d.volunteers.trained + '）</div></div>' +
      '<div class="stat-card"><div class="num">' + d.volunteers.hours + '</div><div class="lbl">累计服务时长（小时）</div></div>' +
      '<div class="stat-card"><div class="num">' + d.trainings.done + '</div><div class="lbl">完成培训（' + d.trainings.hours + ' 课时）</div></div>' +
      '<div class="stat-card"><div class="num red">' + d.complaints.open + '</div><div class="lbl">待处理投诉</div></div>' +
    '</div>';

    html += '<div class="panel"><div class="panel-head"><h2>申请类型分布</h2></div>';
    var typeMax = Math.max.apply(null, Object.keys(d.byType).map(function (k) { return d.byType[k]; }).concat([1]));
    C.SERVICE_TYPES.forEach(function (t) {
      html += barRow(t.label, d.byType[t.value], typeMax);
    });
    html += '</div>';

    html += '<div class="panel"><div class="panel-head"><h2>当前状态分布</h2></div>';
    var stMax = Math.max.apply(null, Object.keys(C.APP_STATUS).map(function (k) { return s[k] || 0; }).concat([1]));
    Object.keys(C.APP_STATUS).forEach(function (k) {
      html += barRow(C.APP_STATUS[k].label, s[k] || 0, stMax, C.APP_STATUS[k].dot);
    });
    html += '</div>';

    html += '<div class="panel"><div class="panel-head"><h2>近 6 个月服务量（新增申请 / 结案）</h2></div>';
    var monthMax = Math.max.apply(null, d.months.map(function (m) {
      return Math.max(d.appByMonth[m.key] || 0, d.closedByMonth[m.key] || 0);
    }).concat([1]));
    d.months.forEach(function (m) {
      html += '<div class="chart-month"><span class="chart-label">' + m.label + '</span>' +
        '<span class="chart-track"><span class="chart-fill" style="width:' + Math.round((d.appByMonth[m.key] || 0) / monthMax * 100) + '%;background:#1f7a5d"></span></span>' +
        '<span class="chart-val">新增 ' + (d.appByMonth[m.key] || 0) + '</span></div>';
      html += '<div class="chart-month sub"><span class="chart-label">　</span>' +
        '<span class="chart-track"><span class="chart-fill" style="width:' + Math.round((d.closedByMonth[m.key] || 0) / monthMax * 100) + '%;background:#d9732a"></span></span>' +
        '<span class="chart-val">结案 ' + (d.closedByMonth[m.key] || 0) + '</span></div>';
    });
    html += '</div>';

    html += '<div class="panel"><div class="panel-head"><h2>回访满意度分布</h2></div>';
    if (!Store.followupList().length) {
      html += '<div class="panel-note">暂无回访记录。</div>';
    } else {
      var satMax = Math.max.apply(null, [1, 2, 3, 4, 5].map(function (n) { return d.satisfaction.dist[n]; }));
      [5, 4, 3, 2, 1].forEach(function (n) {
        html += barRow('★'.repeat(n) + '☆'.repeat(5 - n), d.satisfaction.dist[n], satMax, '#d9a52e');
      });
      html += '<div class="panel-note">平均满意度：' + (d.satisfaction.avg === null ? '—' : d.satisfaction.avg + ' / 5') + '</div>';
    }
    html += '</div>';

    $('#adminContent').innerHTML = html;
  }

  /* ---------------- AI 问答质量分析 ---------------- */
  function renderQaQuality() {
    var q = Store.qaStats();
    var html = '<div class="notice-bar notice-info" style="margin-bottom:16px"><div>数据为匿名问答日志（仅问题文本前 120 字，不含身份信息）；命中率=知识库命中数 ÷ 正常问答数，急症安全转介单独统计。</div></div>';
    html += '<div class="stat-grid">' +
      '<div class="stat-card"><div class="num">' + q.total + '</div><div class="lbl">问答总数</div></div>' +
      '<div class="stat-card"><div class="num">' + q.normalTotal + '</div><div class="lbl">正常问答</div></div>' +
      '<div class="stat-card"><div class="num">' + q.matched + '</div><div class="lbl">知识库命中</div></div>' +
      '<div class="stat-card"><div class="num orange">' + q.unmatched + '</div><div class="lbl">无依据（待补充）</div></div>' +
      '<div class="stat-card"><div class="num blue">' + (q.hitRate === null ? '—' : q.hitRate + '%') + '</div><div class="lbl">知识库命中率</div></div>' +
      '<div class="stat-card"><div class="num red">' + q.emergency + '</div><div class="lbl">急症/危险安全转介</div></div>' +
    '</div>';

    html += '<div class="panel"><div class="panel-head"><h2>高频“答不上来”的问题（优先补充知识库）</h2>' +
      '<button class="btn btn-outline btn-sm" type="button" data-go="knowledge">去知识库补充</button></div>';
    if (!q.topUnmatched.length) {
      html += '<div class="empty-state"><p>暂无未命中问题。可在前台 AI 助手多试几类问题，这里会列出需要补充的内容。</p></div>';
    } else {
      html += '<div class="table-wrap"><table><thead><tr><th style="width:80px">次数</th><th>问题</th><th style="width:150px">最近出现</th></tr></thead><tbody>';
      q.topUnmatched.forEach(function (x) {
        html += '<tr><td><b>' + x.count + '</b></td><td>' + esc(x.q) + '</td><td>' + esc(x.lastAt) + '</td></tr>';
      });
      html += '</tbody></table></div>';
    }
    html += '</div>';

    html += '<div class="panel"><div class="panel-note">补充方法：到「政策知识库」新增条目，填写官方来源与核实日期后审核通过；' +
      '未经核实的金额、条件、电话不要录入，宁可不答、不可错答。</div></div>';
    $('#adminContent').innerHTML = html;
  }

  var RENDER = {
    dashboard: renderDashboard, applications: renderApplications, orders: renderOrders,
    followups: renderFollowups, schedules: renderSchedules, reminders: renderReminders,
    knowledge: renderKnowledge, local: renderLocal,
    articles: renderArticles, feedback: renderFeedback,
    volunteers: renderVolunteers, trainings: renderTrainings,
    report: renderReport, qaquality: renderQaQuality, logs: renderLogs
  };

  /* ---------------- 全局事件委托 ---------------- */
  $('#adminNav').addEventListener('click', function (e) {
    var btn = e.target.closest('button[data-view]');
    if (btn) setView(btn.getAttribute('data-view'));
  });
  $('#adminContent').addEventListener('click', function (e) {
    var go = e.target.closest('[data-go]');
    if (go) { setView(go.getAttribute('data-go')); return; }
    var act = e.target.closest('[data-act]');
    if (!act) return;
    var id = act.getAttribute('data-id');
    var a = act.getAttribute('data-act');

    if (a === 'to') {
      var r = Store.setApplicationStatus(id, act.getAttribute('data-next'));
      if (!r.ok) toast(r.msg); else { toast('状态已更新'); renderApplications(); }
    }
    if (a === 'note') noteModal(id);
    if (a === 'reject') rejectModal(id);
    if (a === 'order') orderCreateModal(id);
    if (a === 'oedit') orderEditModal(id);
    if (a === 'orecord') orderRecordModal(id);
    if (a === 'oreject') orderRejectModal(id);
    if (a === 'followup') {
      var o = Store.orderList().find(function (x) { return x.id === id; });
      if (o) { setView('followups'); setTimeout(function () { followupModal(); }, 0); }
    }
    if (a === 'close') closeCaseModal(id);
    if (a === 'cedit') complaintEditModal(id);
    if (a === 'kedit') knowledgeModal(id);
    if (a === 'kapprove') { Store.knowledgeSetStatus(id, 'approved'); toast('已审核通过，进入问答'); renderKnowledge(); }
    if (a === 'kdraft') { Store.knowledgeSetStatus(id, 'draft'); toast('已退回草稿'); renderKnowledge(); }
    if (a === 'ledit') localModal(id);
    if (a === 'aedit') articleModal(id);
    if (a === 'aapprove') {
      var aa = Store.articleList(true).find(function (x) { return x.id === id; });
      Store.articleSetStatus(id, 'approved', user.realName);
      toast('已审核通过'); renderArticles();
    }
    if (a === 'adraft') { Store.articleSetStatus(id, 'draft', user.realName); toast('已撤回'); renderArticles(); }
    // 二期：志愿者
    if (a === 'vadd') volunteerModal();
    if (a === 'vedit') volunteerModal(id);
    if (a === 'vstatus') {
      Store.volunteerSetStatus(id, act.getAttribute('data-next'));
      toast('状态已更新'); renderVolunteers();
    }
    // 二期：培训
    if (a === 'tadd') trainingModal();
    if (a === 'tedit') trainingModal(id);
    if (a === 'tstatus') {
      Store.trainingSetStatus(id, act.getAttribute('data-next'));
      toast('状态已更新'); renderTrainings();
    }
    // 二期：排班
    if (a === 'scadd') scheduleModal();
    if (a === 'scdone') {
      var rsc = Store.scheduleUpdate(id, { status: 'done' });
      if (!rsc.ok) toast(rsc.msg); else { toast('已登记完成，服务时长计入志愿者档案'); renderSchedules(); }
    }
    if (a === 'sccancel') { Store.scheduleUpdate(id, { status: 'canceled' }); toast('已取消'); renderSchedules(); }
    if (a === 'scdel') {
      if (confirm('确定删除这条排班？')) { Store.scheduleDelete(id); toast('已删除'); renderSchedules(); }
    }
    // 二期：回访提醒
    if (a === 'rmadd') reminderModal();
    if (a === 'rmdone') { Store.reminderDone(id); toast('已标记完成'); renderReminders(); }
    if (a === 'rmdel') { Store.reminderDelete(id); toast('已删除'); renderReminders(); }
  });

  /* ---------------- 申请相关弹窗 ---------------- */
  function noteModal(id) {
    var a = Store.getApplication(id);
    openModal('联系记录与内部备注（' + a.code + '）',
      '<div class="form-row"><label class="field-label">新增联系情况</label><textarea id="nText" placeholder="例如：10 月 21 日 15:00 电话联系，本人接听，确认需要每月 2 次上门保洁；普通话沟通不畅，已安排维语志愿者。"></textarea></div>' +
      '<div class="form-row"><label class="field-label">内部处理备注（仅工作人员可见）</label><textarea id="nNote">' + esc(a.internalNote || '') + '</textarea></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-primary" type="button" id="mOk">保存</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      if (val('nText')) { var r1 = Store.addContactLog(id, val('nText')); if (!r1.ok) { toast(r1.msg); return; } }
      Store.saveInternalNote(id, val('nNote'));
      closeModal(); toast('已保存'); renderApplications();
    });
  }

  function rejectModal(id) {
    var a = Store.getApplication(id);
    openModal('暂无法处理（' + a.code + '）',
      '<div class="notice-bar notice-danger" style="margin-bottom:12px"><div>必须填写原因和转介建议，居民在进度查询中可以看到。</div></div>' +
      '<div class="form-row"><label class="field-label">原因与转介建议</label><textarea id="rReason" placeholder="例如：该需求超出本项目服务范围，建议联系 XX 部门；已告知申请人拨打 12345。"></textarea></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-primary" type="button" id="mOk">确认暂无法处理</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      if (val('rReason').length < 6) { toast('请填写原因和转介建议'); return; }
      var r = Store.setApplicationStatus(id, 'rejected', { reason: val('rReason') });
      if (!r.ok) toast(r.msg); else { closeModal(); toast('已标记暂无法处理'); renderApplications(); }
    });
  }

  function orderCreateModal(appId) {
    var a = Store.getApplication(appId);
    openModal('创建工单并派单（' + a.code + '）',
      '<div class="form-row"><label class="field-label">服务负责人</label><input class="input" id="oOwner" placeholder="如：工作人员 staff / 志愿者姓名" value="' + user.username + '"></div>' +
      '<div class="form-row"><label class="field-label">计划服务时间</label><input class="input" id="oTime" placeholder="如：每周三下午，首次 10 月 24 日"></div>' +
      '<div class="form-row"><label class="field-label">服务安排说明</label><textarea id="oProgress" placeholder="服务内容、注意事项、语言需求等"></textarea></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-accent" type="button" id="mOk">创建工单并派单</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      if (!val('oOwner')) { toast('请指定服务负责人'); return; }
      var r = Store.createOrder(appId, val('oOwner'), val('oTime'));
      if (!r.ok) { toast(r.msg); return; }
      if (val('oProgress')) Store.updateOrder(r.order.id, { progress: val('oProgress') });
      closeModal(); toast('工单已创建，申请进入“已安排”'); renderApplications();
    });
  }

  function orderEditModal(id) {
    var o = Store.orderList().find(function (x) { return x.id === id; });
    openModal('更新工单信息（' + o.code + '）',
      '<div class="form-row"><label class="field-label">服务负责人</label><input class="input" id="eOwner" value="' + esc(o.owner || '') + '"></div>' +
      '<div class="form-row"><label class="field-label">计划服务时间</label><input class="input" id="eTime" value="' + esc(o.plannedAt || '') + '"></div>' +
      '<div class="form-row"><label class="field-label">服务进展</label><textarea id="eProgress">' + esc(o.progress || '') + '</textarea></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-primary" type="button" id="mOk">保存</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      var r = Store.updateOrder(id, { owner: val('eOwner'), plannedAt: val('eTime'), progress: $('#eProgress').value });
      if (!r.ok) toast(r.msg); else { closeModal(); toast('已保存'); renderOrders(); }
    });
  }

  function orderRecordModal(id) {
    var o = Store.orderList().find(function (x) { return x.id === id; });
    openModal('填写服务记录（' + o.code + '）',
      '<div class="form-row"><label class="field-label">本次服务内容与情况</label><textarea id="recText" placeholder="例如：10 月 24 日 15:00 首次上门，完成居家保洁 1 小时，讲解防跌倒要点，家属在场，服务对象满意。"></textarea></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-primary" type="button" id="mOk">保存记录</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      if (val('recText').length < 5) { toast('请填写服务记录'); return; }
      var r = Store.addOrderRecord(id, val('recText'));
      if (!r.ok) toast(r.msg); else { closeModal(); toast('记录已保存'); renderOrders(); }
    });
  }

  function orderRejectModal(id) {
    var o = Store.orderList().find(function (x) { return x.id === id; });
    openModal('工单暂无法处理（' + o.code + '）',
      '<div class="form-row"><label class="field-label">原因</label><textarea id="orReason"></textarea></div>' +
      '<div class="form-row"><label class="field-label">转介建议</label><textarea id="orReferral" placeholder="如：建议联系残联或社区卫生服务中心"></textarea></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-primary" type="button" id="mOk">确认</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      if (val('orReason').length < 5) { toast('请填写原因'); return; }
      var r = Store.updateOrder(id, { status: 'rejected', rejectReason: val('orReason'), referral: val('orReferral') });
      if (!r.ok) toast(r.msg); else { closeModal(); toast('已登记'); renderOrders(); }
    });
  }

  function closeCaseModal(id) {
    var o = Store.orderList().find(function (x) { return x.id === id; });
    openModal('结案（' + o.code + '）',
      '<div class="form-row"><label class="field-label">结案小结</label><textarea id="csText" placeholder="例如：完成约定的 4 次上门服务，回访满意，家属已掌握基础照护方法，结案。"></textarea></div>',
      '<button class="btn btn-ghost" type="button" id="mCancel">取消</button>' +
      '<button class="btn btn-accent" type="button" id="mOk">确认结案</button>');
    $('#mCancel').addEventListener('click', closeModal);
    $('#mOk').addEventListener('click', function () {
      if (val('csText').length < 5) { toast('请填写结案小结'); return; }
      var r = Store.closeCase(o.appCode, val('csText'));
      if (!r.ok) toast(r.msg); else { closeModal(); toast('已结案'); renderOrders(); }
    });
  }

  /* ---------------- 顶部/侧边操作 ---------------- */
  $('#logoutBtn').addEventListener('click', function () {
    Store.logout(); location.href = 'login.html';
  });
  $('#resetDemo').addEventListener('click', function () {
    if (!confirm('将清空本机所有申请、工单、回访、投诉和反馈，恢复为初始数据。确定继续？')) return;
    Store.resetDemo();
    toast('本地数据已重置');
    setView('dashboard');
  });
  $('#sidebarToggle').addEventListener('click', function () {
    $('#sidebar').classList.toggle('open');
  });

  /* ---------------- 角色与初始化 ---------------- */
  $('#sideUser').innerHTML = esc(user.realName) + '（' + esc(C.ROLES[user.role].label) + '）';
  $('#topUser').textContent = user.realName;
  $('#topRole').textContent = C.ROLES[user.role].label;
  $all('#adminNav button[data-role]').forEach(function (b) {
    var need = b.getAttribute('data-role');
    if (user.role !== 'admin' && need !== user.role) {
      b.disabled = true;
      b.title = '当前角色无权访问';
    }
  });
  if (user.role !== 'admin') {
    var rb = $('#resetDemo');
    if (rb) rb.disabled = true;
  }

  setView('dashboard');
})();
