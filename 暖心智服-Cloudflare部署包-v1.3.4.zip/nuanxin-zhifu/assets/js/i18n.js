/* ============================================================
   暖心智服 · 静态网站  汉维双语字典（中文 / ئۇيغۇرچە）
   - 维吾尔语使用 RTL（从右向左）排版
   - 已校对：导航、主要按钮、核心指引、服务名称等界面词汇
   - 政策、医疗、授权等长段内容仍以中文为准（切换维语时顶部有提示）
   ============================================================ */
(function (window) {
  const dict = {
    zh: {
      'brand': '暖心智服',
      'brand.full': '暖心智服——新疆 AI 便民公益服务平台',
      'brand.sub': '新疆 AI 便民公益服务平台',

      'top.welcome': '欢迎访问暖心智服——新疆 AI 便民公益服务平台（试点建设中）',
      'top.hotline': '政务热线：12345',
      'top.admin': '工作后台',
      'common.lang_switch': 'ئۇيغۇرچە',
      'common.large_font': '大字版',
      'a11y.large_on': '已开启大字版',
      'a11y.large_off': '已关闭大字版',
      'ug.notice': '维吾尔语界面正在完善中：导航、主要按钮与核心指引已提供双语，政策、医疗、授权等关键内容以中文为准。',

      'nav.home': '首页',
      'nav.ai': 'AI 便民助手',
      'nav.apply': '公益帮扶',
      'nav.local': '本地便民',
      'nav.health': '康复与健康',
      'nav.track': '服务进度',
      'nav.about': '关于我们',

      'common.ask': '提问',
      'common.submit': '提交',
      'common.reset': '重置',
      'common.save': '保存',
      'common.cancel': '取消',
      'common.back': '返回',
      'common.required': '必填',
      'common.optional': '选填',
      'common.loading': '正在处理…',
      'common.feedback': '意见反馈',
      'common.privacy': '隐私政策',
      'common.terms': '服务声明',
      'common.human_help': '转人工核实',
      'common.report_answer': '反馈答案问题',
      'common.demo_tag': '试点版',
      'common.demo_banner': '试点阶段提示：本平台目前为静态版，您提交的申请与反馈仅保存在本人浏览器中，工作人员暂不能在线查看；需要帮扶请直接拨打 12345 或联系青年路西社区。',
      'common.planned_tag': '规划目标 · 待落实',
      'common.demo_data_tag': '待核实',
      'common.verified_tag': '已核实',
      'common.pending_review_tag': '待专业审核',
      'common.official_note': '本平台为学生公益项目，不代表任何政府部门；平台不开展募捐活动，核心基础服务免费。',

      'hero.badge': '汉维双语 · 公益免费 · 入户服务',
      'hero.title': '政策看得懂、办事有人帮、困难有人管',
      'hero.lead': '面向新疆本地居民与特殊困难群体的一站式公益服务入口：AI 政策问答、公益帮扶申请、便民信息查询、服务进度跟踪，由护理、康复相关专业大学生团队运营。',
      'hero.placeholder': '请输入您的问题，例如：残疾人两项补贴去哪里咨询？',
      'hero.cta_apply': '申请公益帮扶',
      'hero.cta_ai': '进入 AI 便民助手',
      'hero.stat1': '三类重点服务对象',
      'hero.stat2': '八步标准化服务流程',
      'hero.stat3': '汉维双语全程沟通',

      'entry.ai': 'AI 政策问答',
      'entry.ai_d': '基于审核知识库，办事指引有依据',
      'entry.apply': '公益帮扶申请',
      'entry.apply_d': '七类入户服务，线上提交需求',
      'entry.local': '本地便民服务',
      'entry.local_d': '政务、助残、未保渠道汇总',
      'entry.track': '服务进度查询',
      'entry.track_d': '编号 + 手机号，查询办理进展',
      'entry.health': '康复健康科普',
      'entry.health_d': '居家康复与照护安全知识',
      'entry.human': '人工帮助',
      'entry.human_d': '答不准、不会用，留言转人工',

      'home.notice': '平台公告',
      'home.more': '更多',
      'home.objects.title': '重点服务对象',
      'home.objects.sub': '聚焦最需要帮助的三类群体，分级分类、一人一策',
      'home.flow.title': '标准化八步服务流程',
      'home.flow.sub': '每次服务有档案、有记录、有回访，季度复评、动态调整',
      'home.features.title': '项目特色',
      'home.plan.title': '发展规划',
      'home.plan.sub': '以下目标均来自《项目综述》规划，尚在推进落实中，不代表已签约或已实现',
      'home.partners.title': '多方协作机制（试点对接中）',
      'home.partners.sub': '项目拟在慈善总会统筹下，联动社区、残联、未成年人保护工作站、高校与社区卫生机构；其中伊州区青年路西社区已出具合作意向证明，同意开展试点调研与入户服务，其余均为规划设想。',

      'objects.o1': '重度残疾人及家庭',
      'objects.o1d': '持有一、二级重度残疾证、长期居家、行动受限的居民，尤其是独居重度残疾人、“依老养残”家庭。',
      'objects.o2': '留守儿童、困境儿童',
      'objects.o2d': '缺乏父母有效监护与亲情陪伴的农村留守儿童，以及需要帮扶的困境儿童及其家庭。',
      'objects.o3': '自闭症儿童家庭',
      'objects.o3d': '需要居家适应支持、低刺激陪伴、家庭照护科普与喘息支持的自闭症儿童及其家庭。',
      'objects.other': '次要服务对象：持有三、四级残疾证的轻中度残疾人，以按需响应、定期回访的方式提供咨询、科普与必要协助。',

      'flow.1': '需求摸排与建档', 'flow.2': '需求评估', 'flow.3': '分级分类', 'flow.4': '人员派单',
      'flow.5': '上门服务', 'flow.6': '服务记录', 'flow.7': '回访复评', 'flow.8': '档案更新',

      'plan.s1': '短期（0—12 个月）',
      'plan.s1d': '首个试点社区伊州区青年路西社区已出具加盖公章的合作意向证明，2026 年 9 月 5 日起试点实行；规划再对接 2 个街道社区，共服务约 200 名困境对象，验证服务模式。',
      'plan.s2': '中期（1—3 年）',
      'plan.s2d': '规划拓展至 5—8 个社区，服务 700—1200 人，完善残童一体化服务体系。',
      'plan.s3': '长期（3—5 年）',
      'plan.s3d': '规划形成可复制的服务标准体系，向周边区县推广，扩展就业辅导、家庭喘息等多元服务。',

      'footer.desc': '面向新疆本地、汉维双语、全免费、入户式的 AI 便民公益帮扶项目，重点服务重度残疾人、留守儿童和困境儿童、自闭症儿童家庭。',
      'footer.column_service': '便民服务',
      'footer.column_about': '项目信息',
      'footer.column_contact': '求助与联系',
      'footer.hotline': '政务服务便民热线：12345',
      'footer.emergency': '紧急求助：110 · 120 · 119',
      'footer.notice': '本平台为学生公益项目，不开展募捐活动，不收取核心服务费用；规划中的合作、人数与目标均待落实，不代表已经签约、已服务或获得官方背书。',
      'footer.copyright': '核心基础服务免费 · 规划事项以实际落实为准'
    },

    ug: {
      'brand': 'مېھىرلىك ئەقلىي مۇلازىمەت',
      'brand.full': 'مېھىرلىك ئەقلىي مۇلازىمەت — شىنجاڭ AI قولايلىق ئىجتىمائىي پاراۋانلىق مۇلازىمەت سۇپىسى',
      'brand.sub': 'شىنجاڭ AI قولايلىق ئىجتىمائىي پاراۋانلىق مۇلازىمەت سۇپىسى',

      'top.welcome': 'مېھىرلىك ئەقلىي مۇلازىمەت سۇپىسىغا مەرھەبەت (سىناق باسقۇچىدا)',
      'top.hotline': 'ھۆكۈمەت قىزىق لىنىيىسى: 12345',
      'top.admin': 'خىزمەت سۇپىسى',
      'common.lang_switch': '中文',
      'common.large_font': 'چوڭ خەت',
      'a11y.large_on': 'چوڭ خەت ھالىتى ئېچىلدى',
      'a11y.large_off': 'چوڭ خەت ھالىتى تاقالدى',
      'ug.notice': 'ئۇيغۇرچە كۆرۈنمە يۈز مۇكەممەللەشتۈرۈلىۋاتىدۇ؛ مۇھىم سىياسەت، ساغلاملىق ۋە ھوقۇق مەزمۇنلىرى خەنزۇچە نۇسخىغا ئاساسلىنىدۇ.',

      'nav.home': 'باش بەت',
      'nav.ai': 'AI قۇلايلىق ياردەمچى',
      'nav.apply': 'پاراۋانلىق ياردىمى',
      'nav.local': 'يەرلىك قولايلىق',
      'nav.health': 'ساقايتىش ۋە ساغلاملىق',
      'nav.track': 'مۇلازىمەت ئىلگىرىلەش',
      'nav.about': 'بىز ھەققىدە',

      'common.ask': 'سوراش',
      'common.submit': 'يوللاش',
      'common.reset': 'ئەسلىگە كەلتۈرۈش',
      'common.save': 'ساقلاش',
      'common.cancel': 'بىكار قىلىش',
      'common.back': 'قايتىش',
      'common.required': 'چوقۇم تولدۇرۇلىدۇ',
      'common.optional': 'تاللاشچان',
      'common.loading': 'بىر تەرەپ قىلىنىۋاتىدۇ…',
      'common.feedback': 'پىكىر-تەكلىپ',
      'common.privacy': 'مەخپىيەتلىك',
      'common.terms': 'مۇلازىمەت باياناتنامىسى',
      'common.human_help': 'خادىمغا يۆتكەش',
      'common.report_answer': 'جاۋابتا مەسىلە بار',
      'common.demo_tag': 'ستاتىك كۆرگەزمە نۇسخىسى',
      'common.demo_banner': 'بۇ ستاتىك كۆرگەزمە نۇسخىسى: سانلىق مەلۇمات پەقەت مۇشۇ تور كۆرگۈچتە ساقلىنىدۇ؛ رەسمىي ئىشلىتىلگەندە مۇلازىمېتىردا ساقلىنىدۇ.',
      'common.planned_tag': 'پىلان نىشانى · كۈتۈلىدۇ',
      'common.demo_data_tag': 'كۆرگەزمە سانلىق مەلۇمات',
      'common.verified_tag': 'دەلىللەندى',
      'common.pending_review_tag': 'تەكشۈرۈلمىدى',
      'common.official_note': 'بۇ سۇپا ئوقۇغۇچىلار خەيرىخاھلىق تۈرى، ھېچقانداق ھۆكۈمەت تارمىقىغا ۋەكىللىك قىلمايدۇ؛ ئىئانە توپلىمايدۇ.',

      'hero.badge': 'خەنزۇچە-ئۇيغۇرچە قوش تىل · ھەقسىز · ئۆيگە بېرىپ مۇلازىمەت',
      'hero.title': 'سىياسەتنى چۈشىنىمىز، ئىشىڭىزغا ياردەملىشىمىز، قىيىنچىلىقىڭىزنى ھەل قىلىمىز',
      'hero.lead': 'شىنجاڭ ئاھالىلىرى ۋە ئالاھىدە قىيىن گۇرۇپپىلارغا قارىتىلغان بىر بېكەتلىك پاراۋانلىق مۇلازىمەت كىرىش ئېغىزى.',
      'hero.placeholder': 'سوئالىڭىزنى كىرگۈزۈڭ، مەسىلەن: مېيىپلىك ياردەم پۇلىنى نەدىن سورايمەن؟',
      'hero.cta_apply': 'ياردەمگە ئىلتىماس',
      'hero.cta_ai': 'AI ياردەمچىگە كىرىش',
      'hero.stat1': 'ئۈچ تۈرلۈك نۇقتىلىق ئوبيېكت',
      'hero.stat2': 'سەككىز قەدەملىك ئۆلچەملىك جەريان',
      'hero.stat3': 'قوش تىللىق ئالاقە',

      'entry.ai': 'AI سىياسەت سوئال-جاۋابى',
      'entry.ai_d': 'تەكشۈرۈلگەن بىلىم ئامبىرىغا ئاساسلىنىدۇ',
      'entry.apply': 'پاراۋانلىق ياردەم ئىلتىماسى',
      'entry.apply_d': 'يەتتە تۈرلۈك ئۆيگە بېرىپ مۇلازىمەت',
      'entry.local': 'يەرلىك قولايلىق مۇلازىمەت',
      'entry.local_d': 'ھۆكۈمەت، مېيىپلەر، بالىلار قاناللىرى',
      'entry.track': 'مۇلازىمەت ئىلگىرىلىشى',
      'entry.track_d': 'نومۇر + تېلېفون نومۇرى بىلەن سۈرۈشتۈرۈش',
      'entry.health': 'ساقايتىش بىلىمى',
      'entry.health_d': 'ئائىلە ساقايتىش بىلىملىرى',
      'entry.human': 'خادىم ياردىمى',
      'entry.human_d': 'ئىنكاس قالدۇرۇپ خادىمغا يۆتكەش',

      'home.notice': 'سۇپا ئۇقتۇرۇشى',
      'home.more': 'تېخىمۇ كۆپ',
      'home.objects.title': 'نۇقتىلىق مۇلازىمەت ئوبيېكتلىرى',
      'home.objects.sub': 'ئۈچ تۈرلۈك گۇرۇپپىنى مەركەزلەشتۈرۈش',
      'home.flow.title': 'سەككىز قەدەملىك ئۆلچەملىك مۇلازىمەت جەريانى',
      'home.flow.sub': 'ھەر قېتىملىق مۇلازىمەتنىڭ خاتىرىسى ۋە قايتا يوقلىشى بولىدۇ',
      'home.features.title': 'تۈر ئالاھىدىلىكى',
      'home.plan.title': 'تەرەققىيات پىلانى',
      'home.plan.sub': 'تۆۋەندىكى نىشانلار پىلاندىكى مەزمۇن، تېخى ئەمەلگە ئاشمىدى',
      'home.partners.title': 'كۆپ تەرەپ ھەمكارلىق مېخانىزمى (سىناق باسقۇچىدا)',
      'home.partners.sub': 'بۇ تۈر سىناق باسقۇچىدا؛ ئايرىم مەھەللە بىلەن ھەمكارلىق نىيىتى بېكىتىلدى، باشقا ھەمكارلىقلار تېخى پىلان باسقۇچىدا.',

      'objects.o1': 'ئېغىر مېيىپلەر ۋە ئائىلىسى',
      'objects.o1d': 'بىرىنچى، ئىككىنچى دەرىجىلىك ئېغىر مېيىپلىك كىنىشكىسى بار، ئۇزۇن مۇددەت ئۆيدە تۇرىدىغان ئاھالىلەر.',
      'objects.o2': 'ئاتا-ئانىسى يوق ئۆيلەردە قالغان ۋە قىيىن ئەھۋالدىكى بالىلار',
      'objects.o2d': 'ئاتا-ئانىسىنىڭ كۆڭۈل بۆلۈشى كەم قالغان يېزىدىكى بالىلار ۋە ئائىلىسى.',
      'objects.o3': 'ئاپتىزملىق بالىلار ئائىلىسى',
      'objects.o3d': 'تۆۋەن غىدىقلىنىشلىق ھەمراھلىق ۋە پەرۋىش بىلىمىگە ئېھتىياجلىق ئائىلىلەر.',
      'objects.other': 'ئىككىنچى دەرىجىلىك ئوبيېكت: ئۈچىنچى، تۆتىنچى دەرىجىلىك يېنىك-ئوتتۇراھال مېيىپلەر.',

      'flow.1': 'ئېھتىياجنى ئېنىقلاش ۋە ھۆججەت قىلىش', 'flow.2': 'ئېھتىياجنى باھالاش', 'flow.3': 'دەرىجىگە ئايرىش', 'flow.4': 'خادىم تەقسىملەش',
      'flow.5': 'ئۆيگە بېرىپ مۇلازىمەت', 'flow.6': 'مۇلازىمەت خاتىرىسى', 'flow.7': 'قايتا يوقلاش ۋە قايتا باھالاش', 'flow.8': 'ھۆججەتنى يېڭىلاش',

      'plan.s1': 'قىسقا مۇددەت (0—12 ئاي)',
      'plan.s1d': 'دەسلەپتە 3 مەھەللىدە سىناق قىلىپ، تەخمىنەن 200 ئادەمگە مۇلازىمەت قىلىش پىلانلانغان.',
      'plan.s2': 'ئوتتۇرا مۇددەت (1—3 يىل)',
      'plan.s2d': '5—8 مەھەللىگە كېڭەيتىپ، 700—1200 ئادەمگە مۇلازىمەت قىلىش پىلانلانغان.',
      'plan.s3': 'ئۇزۇن مۇددەت (3—5 يىل)',
      'plan.s3d': 'كۆچۈرگىلى بولىدىغان ئۆلچەم سىستېمىسى شەكىللەندۈرۈلۈپ، ئەتراپتىكى رايونلارغا كېڭەيتىش پىلانلانغان.',

      'footer.desc': 'شىنجاڭغا قارىتىلغان قوش تىللىق، ھەقسىز، ئۆيگە بېرىپ ئىشلەيدىغان خەيرىخاھلىق تۈرى.',
      'footer.column_service': 'قولايلىق مۇلازىمەت',
      'footer.column_about': 'تۈر ئۇچۇرى',
      'footer.column_contact': 'ياردەم ۋە ئالاقە',
      'footer.hotline': 'ھۆكۈمەت مۇلازىمەت قىزىق لىنىيىسى: 12345',
      'footer.emergency': 'جىددىي ياردەم: 110 · 120 · 119',
      'footer.notice': 'بۇ بەت ئوقۇغۇچىلار خەيرىخاھلىق تۈرى؛ پىلان قىلىنغان ھەمكارلىق ۋە نىشانلار كۈتۈلىدۇ.',
      'footer.copyright': 'ئاساسىي مۇلازىمەت ھەقسىز · پىلان ئەمەلىي ئەمەلگە ئېشىشكە قارىلىدۇ'
    }
  };

  let currentLang = localStorage.getItem('nxf_lang') || 'zh';

  function t(key, lang) {
    const l = lang || currentLang;
    return (dict[l] && dict[l][key] !== undefined) ? dict[l][key]
      : (dict.zh[key] !== undefined ? dict.zh[key] : key);
  }

  function applyLang(lang) {
    currentLang = lang === 'ug' ? 'ug' : 'zh';
    const root = document.documentElement;
    root.lang = currentLang === 'ug' ? 'ug' : 'zh';
    root.dir = currentLang === 'ug' ? 'rtl' : 'ltr';
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      const v = t(el.getAttribute('data-i18n'));
      if (v.indexOf('\n') !== -1) {
        el.innerHTML = v.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
      } else {
        el.textContent = v;
      }
    });
    document.querySelectorAll('[data-i18n-ph]').forEach((el) => {
      el.setAttribute('placeholder', t(el.getAttribute('data-i18n-ph')));
    });
    document.querySelectorAll('[data-i18n-title]').forEach((el) => {
      el.setAttribute('title', t(el.getAttribute('data-i18n-title')));
    });
    localStorage.setItem('nxf_lang', currentLang);
    window.dispatchEvent(new CustomEvent('langchange', { detail: { lang: currentLang } }));
  }

  function toggleLang() {
    applyLang(currentLang === 'zh' ? 'ug' : 'zh');
  }

  window.I18N = {
    t, applyLang, toggleLang,
    get lang() { return currentLang; }
  };
})(window);
